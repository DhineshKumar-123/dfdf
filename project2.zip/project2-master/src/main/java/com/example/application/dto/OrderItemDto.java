package com.example.application.dto;

import lombok.Data;

@Data
public class OrderItemDto {

    private Long id;
    private Long productId;
    private int quantity;
}
