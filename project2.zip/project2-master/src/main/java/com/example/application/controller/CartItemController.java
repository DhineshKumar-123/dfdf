package com.example.application.controller;

import com.example.application.dto.CartItemDto;
import com.example.application.entity.User;
import com.example.application.service.CartItemService;
import com.example.application.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/cartitems")
public class CartItemController {

    @Autowired
    private CartItemService cartItemService;

    @Autowired
    private UserService userService;


    @GetMapping
    public String viewCartItems(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<CartItemDto> cartItems = cartItemService.getCartItemsByUser(user.getId());
        double total = cartItemService.getTotalAmount(user.getId());

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalAmount", total);

        return "cartitem/list";
    }


    @GetMapping("/view")
    public String viewCartItemsAlias(Model model, Principal principal) {
        return viewCartItems(model, principal);
    }


    @GetMapping("/add/{productId}")
    public String addToCart(@PathVariable Long productId, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        cartItemService.addToCart(user.getId(), productId, 1);
        return "redirect:/cartitems";
    }


    @PostMapping("/update/{id}")
    public String updateQuantity(@PathVariable Long id, @RequestParam int quantity) {
        cartItemService.updateQuantity(id, quantity);
        return "redirect:/cartitems";
    }

    @GetMapping("/delete/{id}")
    public String deleteCartItem(@PathVariable Long id) {
        cartItemService.removeFromCart(id);
        return "redirect:/cartitems";
    }


    @GetMapping("/checkout")
    public String checkout(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        double total = cartItemService.getTotalAmount(user.getId());
        model.addAttribute("totalAmount", total);

        return "cartitem/checkout";
    }

    @GetMapping("/increase/{id}")
    public String increaseQuantity(@PathVariable Long id) {
        cartItemService.increaseQuantity(id);
        return "redirect:/cartitems";
    }


    @GetMapping("/decrease/{id}")
    public String decreaseQuantity(@PathVariable Long id) {
        cartItemService.decreaseQuantity(id);
        return "redirect:/cartitems";
    }
}
