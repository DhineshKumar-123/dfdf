package com.example.application.service;

import com.example.application.dto.CartItemDto;
import com.example.application.dto.PaymentDto;
import java.util.List;
import java.util.Map;

public interface PaymentService {


    CartItemDto getCartItemById(Long id);



    PaymentDto createPayment(PaymentDto paymentDto);
    PaymentDto getPaymentById(Long id);
    List<PaymentDto> getAllPayments();
    PaymentDto updatePayment(Long id, PaymentDto paymentDto);
    void deletePayment(Long id);
    List<PaymentDto> getPaymentsByUser(String email);
    PaymentDto savePayment(PaymentDto payment);
    PaymentDto findByRazorpayOrderId(String razorpayOrderId);
    Map<String, Object> createRazorpayOrder(PaymentDto paymentDto);

}
