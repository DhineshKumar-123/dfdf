package com.example.application.controller;

import com.example.application.dto.OrderDto;
import com.example.application.dto.PaymentDto;
import com.example.application.dto.ProductDto;
import com.example.application.entity.User;
import com.example.application.service.OrderService;
import com.example.application.service.PaymentService;
import com.example.application.service.ProductService;
import com.example.application.service.UserService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.util.List;

@Controller
@RequestMapping("/orders")
public class OrderController {

    private final OrderService orderService;
    private final ProductService productService;
    private final UserService userService;
    private final PaymentService paymentService;
    private final ModelMapper modelMapper;

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    @Autowired
    public OrderController(OrderService orderService,
                           ProductService productService,
                           UserService userService,
                           ModelMapper modelMapper, PaymentService paymentService) {
        this.orderService = orderService;
        this.productService = productService;
        this.userService = userService;
        this.paymentService = paymentService;


        this.modelMapper = modelMapper;
    }

    @GetMapping
    public String defaultRedirect() {
        return "redirect:/orders/view";
    }

    @GetMapping("/create")
    public String showCreateOrderForm(@RequestParam("productId") Long productId,
                                      @RequestParam(value = "quantity", required = false, defaultValue = "1") Integer quantity,
                                      Model model,
                                      Authentication authentication) {
        ProductDto product = productService.getProductById(productId);
        if (product == null) {
            return "redirect:/products/list?error=Product+not+found";
        }

        String email = authentication.getName();
        User user = userService.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        OrderDto orderDto = new OrderDto();
        orderDto.setProductId(product.getId());
        orderDto.setProductName(product.getName());
        orderDto.setUserEmail(user.getEmail());
        orderDto.setUserName(user.getName());
        orderDto.setQuantity(quantity);


        BigDecimal total = (product.getPrice() != null ? product.getPrice() : BigDecimal.ZERO)
                .multiply(BigDecimal.valueOf(quantity))
                .setScale(2, BigDecimal.ROUND_HALF_UP);



        orderDto.setTotalPrice(total.doubleValue());
        orderDto.setOrderStatus("CREATED");

        model.addAttribute("order", orderDto);
        model.addAttribute("product", product);
        return "order/create";
    }
    @PostMapping("/pay")
    public String createRazorpayOrder(@ModelAttribute("order") OrderDto orderDto,
                                      Model model,
                                      Authentication authentication) {
        try {
            String email = authentication.getName();
            User user = userService.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            orderDto.setUserEmail(user.getEmail());

            BigDecimal totalAmount = BigDecimal.valueOf(orderDto.getTotalPrice()).setScale(2, BigDecimal.ROUND_HALF_UP);
            if (totalAmount.compareTo(BigDecimal.ZERO) <= 0) {
                throw new RuntimeException("Invalid order amount");
            }

            BigDecimal maxAmount = BigDecimal.valueOf(5000000);
            if (totalAmount.compareTo(maxAmount) > 0) {
                throw new RuntimeException("Amount exceeds maximum allowed limit of ₹50,00,000.");
            }

            long amountInPaise = totalAmount.multiply(BigDecimal.valueOf(100)).longValue();

            OrderDto savedOrder = orderService.findExistingUnpaidOrder(user.getEmail(), orderDto.getProductId());
            if (savedOrder == null) {
                savedOrder = orderService.createOrder(orderDto);
            }


            RazorpayClient razorpay = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
            JSONObject options = new JSONObject();
            options.put("amount", amountInPaise);
            options.put("currency", "INR");
            options.put("receipt", "order_rcpt_" + savedOrder.getId());
            options.put("payment_capture", 1);
            Order razorOrder = razorpay.orders.create(options);


            PaymentDto payment = new PaymentDto();
            payment.setAmount(totalAmount);
            payment.setPaymentStatus("PENDING");
            payment.setRazorpayOrderId(razorOrder.get("id"));
            payment.setOrderId(savedOrder.getId());
            payment.setUserId(user.getId());
            paymentService.savePayment(payment);

            model.addAttribute("payment", payment);
            model.addAttribute("razorpayOrderId", razorOrder.get("id"));
            model.addAttribute("razorpayKeyId", razorpayKeyId);
            model.addAttribute("amount", totalAmount);
            model.addAttribute("currency", "INR");
            model.addAttribute("order", savedOrder);
            model.addAttribute("user", user);

            return "payment/create";

        } catch (Exception e) {
            model.addAttribute("error", "Error creating Razorpay order: " + e.getMessage());
            return "order/failure";
        }
    }

    @PostMapping("/confirm")
    public String confirmPayment(@RequestParam("razorpay_payment_id") String paymentId,
                                 @RequestParam("razorpay_order_id") String razorOrderId,
                                 @RequestParam("razorpay_signature") String signature,
                                 @RequestParam("orderId") Long orderId,
                                 Authentication authentication,
                                 Model model) {
        try {
            String email = authentication.getName();
            User user = userService.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            OrderDto order = orderService.getOrderById(orderId);
            if (order == null) throw new RuntimeException("Order not found");

            ProductDto product = productService.getProductById(order.getProductId());
            if (product == null) throw new RuntimeException("Product not found");


            order.setOrderStatus("PAID");
            orderService.updateOrderPaymentDetails(orderId, paymentId, razorOrderId, signature);

            PaymentDto payment = paymentService.findByRazorpayOrderId(razorOrderId);
            if (payment == null) payment = new PaymentDto();

            payment.setOrderId(orderId);
            payment.setUserId(user.getId());
            payment.setAmount(BigDecimal.valueOf(order.getTotalPrice()));
            payment.setPaymentStatus("PAID");
            payment.setRazorpayOrderId(razorOrderId);
            payment.setRazorpayPaymentId(paymentId);
            payment.setRazorpaySignature(signature);
            paymentService.savePayment(payment);

            model.addAttribute("order", order);
            model.addAttribute("product", product);
            model.addAttribute("message", "Payment successful!");
            return "order/success";

        } catch (Exception e) {
            model.addAttribute("error", "Payment failed: " + e.getMessage());
            return "order/failure";
        }
    }

    @GetMapping("/view")
    public String viewOrders(Model model, Authentication authentication) {
        try {
            String email = authentication.getName();
            List<OrderDto> orders = orderService.getOrdersByUserEmail(email);
            model.addAttribute("orders", orders);
        } catch (Exception e) {
            model.addAttribute("error", "Error fetching orders: " + e.getMessage());
        }
        return "order/list";
    }

    @GetMapping("/details/{id}")
    public String viewOrderDetails(@PathVariable Long id,
                                   Model model,
                                   Authentication authentication) {
        if (authentication == null) return "redirect:/login";
        String email = authentication.getName();
        OrderDto order = orderService.getOrderById(id);
        if (order == null) {
            model.addAttribute("errorMessage", "Order not found");
            return "redirect:/orders/view";
        }
        ProductDto product = productService.getProductById(order.getProductId());
        model.addAttribute("order", order);
        model.addAttribute("product", product);
        model.addAttribute("razorpayKeyId", razorpayKeyId);
        return "order/view";
    }

    @PostMapping("/cancel/{id}")
    public String cancelOrder(@PathVariable Long id,
                              Authentication authentication,
                              RedirectAttributes redirectAttributes) {
        try {
            String email = authentication.getName();
            if (orderService.isOrderOwnedByUser(id, email)) {
                orderService.updateOrderStatus(id, "CANCELLED");
                redirectAttributes.addFlashAttribute("success", "Order cancelled successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Unauthorized: You cannot cancel this order.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error cancelling order: " + e.getMessage());
        }
        return "redirect:/orders/view";
    }
}

