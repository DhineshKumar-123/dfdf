package com.example.application.controller;

import com.example.application.dto.OrderDto;
import com.example.application.dto.ProductDto;
import com.example.application.dto.UserDto;
import com.example.application.service.OrderService;
import com.example.application.service.ProductService;
import com.example.application.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;
    private final ProductService productService;
    private final OrderService orderService;


    @GetMapping({"/", "/home"})
    public String adminHome() {
        return "admin/dashboard";
    }


    @GetMapping("/orders")
    public String adminOrders(Model model) {
        List<OrderDto> orders = orderService.getAllOrders();
        model.addAttribute("orders", orders);
        return "admin/orders";
    }

    @GetMapping("/orders/delete/{id}")
    public String deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return "redirect:/admin/orders";
    }


    @GetMapping("/users")
    public String listUsers(Model model) {
        List<UserDto> usersList = userService.findAll();
        model.addAttribute("users", usersList);
        return "admin/users";
    }

    @GetMapping("/users/edit/{id}")
    public String editUser(@PathVariable Long id, Model model) {
        UserDto user = userService.findById(id);
        if (user == null) {
            return "error/404";
        }
        model.addAttribute("user", user);
        return "admin/edit-user";
    }


    @PostMapping("/users/update/{id}")
    public String updateUser(
            @PathVariable Long id,
            @ModelAttribute("user") UserDto userDto,
            RedirectAttributes redirectAttributes) {

        try {
            userService.updateUser(id, userDto);
            redirectAttributes.addFlashAttribute("success", "User updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update user: " + e.getMessage());
        }
        return "redirect:/admin/users";
    }

    @GetMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            userService.deleteUser(id);
            redirectAttributes.addFlashAttribute("success", "User deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete user: " + e.getMessage());
        }
        return "redirect:/admin/users";
    }


    @GetMapping("/users/create")
    public String showCreateUserForm(Model model) {
        model.addAttribute("user", new UserDto());
        return "admin/add-user";
    }

    @PostMapping("/users/add")
    public String addUser(@ModelAttribute("user") UserDto userDto, RedirectAttributes redirectAttributes) {
        try {
            userService.createUser(userDto);
            redirectAttributes.addFlashAttribute("success", "User added successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to add user: " + e.getMessage());
        }
        return "redirect:/admin/users";
    }

    @GetMapping("/products")
    public String listProducts(Model model) {
        List<ProductDto> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "admin/products";
    }

    @GetMapping("/products/create")
    public String showCreateForm(Model model) {
        model.addAttribute("product", new ProductDto());
        return "admin/create";
    }

    @PostMapping("/products/create")
    public String createProduct(@ModelAttribute ProductDto productDto,
                                @RequestParam("imageFile") MultipartFile imageFile,
                                Model model) {
        try {
            productService.createProduct(productDto, imageFile);
            return "redirect:/admin/products";
        } catch (Exception e) {
            model.addAttribute("error", "Failed to create product: " + e.getMessage());
            return "admin/create";
        }
    }

    @GetMapping("/products/edit/{id}")
    public String editProduct(@PathVariable Long id, Model model) {
        ProductDto product = productService.getProductById(id);
        if (product == null) {
            return "error/404";
        }
        model.addAttribute("product", product);
        return "admin/edit";
    }

    @PostMapping("/products/update/{id}")
    public String updateProduct(@PathVariable Long id,
                                @ModelAttribute ProductDto productDto,
                                @RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
                                Model model) {
        try {
            productService.updateProductWithImage(id, productDto, imageFile);
            return "redirect:/admin/products";
        } catch (RuntimeException e) {
            model.addAttribute("error", "Could not update product: " + e.getMessage());
            model.addAttribute("product", productDto);
            return "admin/edit";
        }
    }

    @GetMapping("/products/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return "redirect:/admin/products";
    }

    @GetMapping("/orders/edit/{id}")
    public String editOrder(@PathVariable Long id, Model model) {
        OrderDto order = orderService.getOrderById(id);
        if (order == null) {
            return "error/404";
        }
        model.addAttribute("order", order);
        return "admin/edit-order";
    }

    @PostMapping("/orders/update/{id}")
    public String updateOrder(@PathVariable Long id,
                              @RequestParam("quantity") Integer quantity,
                              @RequestParam("totalPrice") Double totalPrice,
                              @RequestParam("orderStatus") String orderStatus,
                              RedirectAttributes redirectAttributes) {
        try {
            OrderDto orderDto = orderService.getOrderById(id);
            if (orderDto == null) {
                redirectAttributes.addFlashAttribute("error", "Order not found!");
                return "redirect:/admin/orders";
            }

            orderDto.setQuantity(quantity);
            orderDto.setTotalPrice(totalPrice);
            orderDto.setOrderStatus(orderStatus);

            orderService.updateOrder(id, orderDto);
            redirectAttributes.addFlashAttribute("success", "Order updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update order: " + e.getMessage());
        }

        return "redirect:/admin/orders";
    }

    @GetMapping("/orders/remove/{id}")
    public String removeOrder(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            orderService.deleteOrder(id);
            redirectAttributes.addFlashAttribute("success", "Order deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete order: " + e.getMessage());
        }
        return "redirect:/admin/orders";
    }
}
