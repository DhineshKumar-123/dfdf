package com.example.application.service.impl;

import com.example.application.dto.OrderDto;
import com.example.application.entity.Order;
import com.example.application.entity.Product;
import com.example.application.entity.User;
import com.example.application.repository.OrderRepository;
import com.example.application.repository.ProductRepository;
import com.example.application.repository.UserRepository;
import com.example.application.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override


    public OrderDto createOrder(OrderDto orderDto) {
        if (orderDto.getUserEmail() == null || orderDto.getUserEmail().isEmpty()) {
            throw new IllegalArgumentException("User email is required to create an order");
        }
        if (orderDto.getProductId() == null) {
            throw new IllegalArgumentException("Product ID is required to create an order");
        }

        Order order = new Order();


        User user = userRepository.findByEmail(orderDto.getUserEmail())
                .orElseThrow(() -> new RuntimeException("User not found with email: " + orderDto.getUserEmail()));
        order.setUser(user);


        Product product = productRepository.findById(orderDto.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found with ID: " + orderDto.getProductId()));
        order.setProduct(product);


        int quantity = (orderDto.getQuantity() != null) ? orderDto.getQuantity() : 1;
        order.setQuantity(quantity);


        BigDecimal price = (product.getPrice() != null) ? product.getPrice() : BigDecimal.ZERO;
        BigDecimal totalPrice = price.multiply(BigDecimal.valueOf(quantity));

        order.setTotalPrice(totalPrice.doubleValue());
        order.setAmount(totalPrice);


        order.setOrderStatus(orderDto.getOrderStatus() != null ? orderDto.getOrderStatus() : "CREATED");
        order.setDate(orderDto.getCreatedAt() != null ? orderDto.getCreatedAt() : LocalDateTime.now());


        order.setRazorpayOrderId(orderDto.getRazorpayOrderId());
        order.setRazorpayPaymentId(orderDto.getRazorpayPaymentId());
        order.setRazorpaySignature(orderDto.getRazorpaySignature());

        Order savedOrder = orderRepository.save(order);

        OrderDto savedDto = new OrderDto();
        savedDto.setId(savedOrder.getId());
        savedDto.setProductId(product.getId());
        savedDto.setUserEmail(user.getEmail());
        savedDto.setUserName(user.getName());
        savedDto.setProductName(product.getName());
        savedDto.setProductPrice(price.doubleValue());
        savedDto.setQuantity(quantity);
        savedDto.setTotalPrice(totalPrice.doubleValue());
        savedDto.setOrderStatus(savedOrder.getOrderStatus());
        savedDto.setCreatedAt(savedOrder.getDate());
        savedDto.setRazorpayOrderId(savedOrder.getRazorpayOrderId());
        savedDto.setRazorpayPaymentId(savedOrder.getRazorpayPaymentId());
        savedDto.setRazorpaySignature(savedOrder.getRazorpaySignature());

        return savedDto;
    }


    @Override
    public OrderDto getOrderById(Long id) {
        return orderRepository.findById(id)
                .map(order -> modelMapper.map(order, OrderDto.class))
                .orElse(null);
    }

    @Override
    public List<OrderDto> getAllOrders() {
        return orderRepository.findAll().stream().map(order -> {
            OrderDto dto = new OrderDto();
            dto.setId(order.getId());
            dto.setOrderStatus(order.getOrderStatus());
            dto.setTotalPrice(order.getTotalPrice() != null ? order.getTotalPrice() : 0.0);
            dto.setQuantity(order.getQuantity());
            dto.setCreatedAt(order.getDate());

            if (order.getUser() != null) {
                dto.setUserName(order.getUser().getName());
                dto.setUserEmail(order.getUser().getEmail());
            }

            if (order.getProduct() != null) {
                dto.setProductId(order.getProduct().getId());
                dto.setProductName(order.getProduct().getName());
                dto.setProductPrice(order.getProduct().getPrice() != null
                        ? order.getProduct().getPrice().doubleValue()
                        : 0.0);
            }

            return dto;
        }).collect(Collectors.toList());
    }






    @Override
    public void cancelOrder(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        order.setOrderStatus("CANCELLED");
        orderRepository.save(order);
    }
    @Override
    public void deleteOrder(Long id) {
        if (!orderRepository.existsById(id)) {
            throw new RuntimeException("Order not found");
        }
        orderRepository.deleteById(id);
    }



    @Override
    public List<OrderDto> getOrdersByProductId(Long productId) {
        return orderRepository.findOrdersByProductId(productId)
                .stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public boolean isOrderOwnedByUser(Long orderId, String email) {
        Optional<Order> order = orderRepository.findById(orderId);
        return order.isPresent() && order.get().getUser().getEmail().equals(email);
    }

  @Override
    public void updateOrderStatus(Long id, String status) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setOrderStatus(status);
        orderRepository.save(order);
    }


    public void createOrder(String email, Long productId, int quantity) {
        OrderDto orderDto = new OrderDto();
        orderDto.setUserEmail(email);
        orderDto.setProductId(productId);
        orderDto.setQuantity(quantity);
        createOrder(orderDto);
    }

    @Override
    public List<OrderDto> getOrdersByUser(String email) {
        return orderRepository.findByUserEmail(email)
                .stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .collect(Collectors.toList());
    }
    @Override
    public List<OrderDto> getOrdersByUserEmail(String email) {
        List<Order> orders = orderRepository.findByUserEmail(email);

        return orders.stream().map(order -> {
            OrderDto dto = new OrderDto();

            dto.setId(order.getId());
            dto.setOrderStatus(order.getOrderStatus());
            dto.setTotalPrice(order.getTotalPrice() != null ? order.getTotalPrice() : 0.0);
            dto.setQuantity(order.getQuantity());

            if (order.getProduct() != null) {
                dto.setProductId(order.getProduct().getId());
                dto.setProductName(order.getProduct().getName());
                dto.setProductPrice(order.getProduct().getPrice() != null
                        ? order.getProduct().getPrice().doubleValue()
                        : 0.0);
                dto.setProductImageUrl(order.getProduct().getImageUrl());
            }

            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public void updateOrderPaymentDetails(Long orderId, String paymentId, String orderIdRazorpay, String signature) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));

        order.setRazorpayPaymentId(paymentId);
        order.setRazorpayOrderId(orderIdRazorpay);
        order.setRazorpaySignature(signature);
        order.setOrderStatus("PAID");

        orderRepository.save(order);
    }
    @Override
    public OrderDto findExistingUnpaidOrder(String userEmail, Long productId) {
        Optional<Order> existingOrder = orderRepository.findAll().stream()
                .filter(order ->
                        order.getUser() != null &&
                                order.getUser().getEmail().equals(userEmail) &&
                                order.getProduct() != null &&
                                order.getProduct().getId().equals(productId) &&
                                !"PAID".equalsIgnoreCase(order.getOrderStatus()))
                .findFirst();

        return existingOrder.map(order -> modelMapper.map(order, OrderDto.class)).orElse(null);
    }
    @Override
    public OrderDto findByRazorpayOrderId(String razorpayOrderId) {
        return orderRepository.findByRazorpayOrderId(razorpayOrderId)
                .map(order -> modelMapper.map(order, OrderDto.class))
                .orElse(null);
    }




    @Override
    public void updateOrder(Long id, OrderDto orderDto) {
        Order existingOrder = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + id));

        existingOrder.setQuantity(orderDto.getQuantity());

        if (existingOrder.getProduct() != null && existingOrder.getProduct().getPrice() != null) {
            double productPrice = existingOrder.getProduct().getPrice().doubleValue();
            existingOrder.setTotalPrice(productPrice * existingOrder.getQuantity());
        } else {
            existingOrder.setTotalPrice(orderDto.getTotalPrice());
        }


        existingOrder.setOrderStatus(orderDto.getOrderStatus());
        existingOrder.setRazorpayOrderId(orderDto.getRazorpayOrderId());
        existingOrder.setRazorpayPaymentId(orderDto.getRazorpayPaymentId());
        existingOrder.setRazorpaySignature(orderDto.getRazorpaySignature());



        orderRepository.save(existingOrder);
    }




}
