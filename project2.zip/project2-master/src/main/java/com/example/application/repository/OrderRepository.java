package com.example.application.repository;

import com.example.application.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    @Query("SELECT DISTINCT o FROM Order o JOIN o.orderItems i WHERE i.product.id = :productId")
    List<Order> findOrdersByProductId(Long productId);

    List<Order> findByUserEmail(String email);

    Optional<Order> findByRazorpayOrderId(String razorpayOrderId);


}
