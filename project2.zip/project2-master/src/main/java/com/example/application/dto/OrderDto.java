    package com.example.application.dto;

    import lombok.Data;

    import java.math.BigDecimal;
    import java.time.LocalDateTime;
    import java.util.List;

    @Data
    public class OrderDto {

        private Long id;

        private Long productId;

        private String userName;

        private String userEmail;

        private String shippingAddress;

        private String productName;

        private Double totalPrice;

        private Integer quantity;

        private String orderStatus;

        private LocalDateTime createdAt = LocalDateTime.now();

        private ProductDto product;

        private String productImageUrl;

        private Double productPrice;


        private String razorpayOrderId;

        private String razorpayPaymentId;

        private String razorpaySignature;

        private String message;



    }
