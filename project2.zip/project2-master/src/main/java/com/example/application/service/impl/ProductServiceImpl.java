package com.example.application.service.impl;

import com.example.application.dto.ProductDto;
import com.example.application.entity.Product;
import com.example.application.repository.ProductRepository;
import com.example.application.service.ProductService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ModelMapper modelMapper;

    private static final String IMAGE_DIR = "src/main/resources/static/images/";

    @Autowired
    public ProductServiceImpl(ProductRepository productRepository, ModelMapper modelMapper) {
        this.productRepository = productRepository;
        this.modelMapper = modelMapper;
    }


    @Override
    public ProductDto createProduct(ProductDto productDto, MultipartFile imageFile) {
        Product product = modelMapper.map(productDto, Product.class);

        try {
            if (imageFile != null && !imageFile.isEmpty()) {

                Files.createDirectories(Paths.get(IMAGE_DIR));


                String fileName = System.currentTimeMillis() + "_" + imageFile.getOriginalFilename();
                Path filePath = Paths.get(IMAGE_DIR, fileName);
                Files.copy(imageFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);


                product.setImageUrl("/images/" + fileName);

            } else {
                product.setImageUrl("/images/default.jpg");
            }

            Product saved = productRepository.save(product);
            return modelMapper.map(saved, ProductDto.class);

        } catch (IOException e) {
            throw new RuntimeException("Error saving product image", e);
        }
    }

    @Override
    public ProductDto updateProductWithImage(Long id, ProductDto productDto, MultipartFile imageFile) {
        try {
            Product existingProduct = productRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Product not found"));

            existingProduct.setName(productDto.getName());
            existingProduct.setDescription(productDto.getDescription());
            existingProduct.setPrice(productDto.getPrice());
            existingProduct.setStock(productDto.getStock());


            String uploadDir = "src/main/resources/static/images/";

            if (imageFile != null && !imageFile.isEmpty()) {

                String fileName = imageFile.getOriginalFilename();
                Path filePath = Paths.get(uploadDir + fileName);


                Files.write(filePath, imageFile.getBytes());

                existingProduct.setImageUrl("/images/" + fileName);
            } else {
                existingProduct.setImageUrl(existingProduct.getImageUrl());
            }

            productRepository.save(existingProduct);
        } catch (IOException e) {
            throw new RuntimeException("Error saving image file", e);
        }
        return productDto;
    }

    @Override
    public ProductDto updateProduct(Long id, ProductDto productDto) {
        Product existing = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        existing.setName(productDto.getName());
        existing.setDescription(productDto.getDescription());
        existing.setPrice(productDto.getPrice());
        existing.setStock(productDto.getStock());
        existing.setQuantity(productDto.getQuantity());
        existing.setImageUrl(productDto.getImageUrl());

        Product updated = productRepository.save(existing);
        return modelMapper.map(updated, ProductDto.class);
    }

    @Override
    public ProductDto getProductById(Long id) {
        return productRepository.findById(id)
                .map(p -> modelMapper.map(p, ProductDto.class))
                .orElse(null);
    }

    @Override
    public List<ProductDto> getAllProducts() {
        return productRepository.findAll()
                .stream()
                .map(p -> modelMapper.map(p, ProductDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    @Override
    public List<ProductDto> searchProducts(String keyword) {
        List<Product> products = productRepository
                .findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCase(keyword, keyword);

        return products.stream()
                .map(p -> modelMapper.map(p, ProductDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public void saveProduct(ProductDto productDto) {
        Product product = modelMapper.map(productDto, Product.class);
        productRepository.save(product);
    }

    @Override
    public void saveProductImage(MultipartFile file, Product product) {
        try {
            Files.createDirectories(Paths.get(IMAGE_DIR));
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path filePath = Paths.get(IMAGE_DIR, fileName);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
            product.setImageUrl("/images/" + fileName);
        } catch (IOException e) {
            throw new RuntimeException("Error saving product image", e);
        }
    }
}
