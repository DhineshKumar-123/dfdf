package com.example.application.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class PaymentDto {

    private Long id;


    private Long orderId;

    private Long userId;
    private Long productId;
    private Integer quantity;
    private String paymentId;

    private String razorpayOrderId;
    private String razorpayPaymentId;
    private String razorpaySignature;

    private String paymentMethod;
    private String paymentStatus;
    private BigDecimal amount;

    private LocalDateTime paymentDate;





    private String currency = "INR";




    private String userEmail;
    private String userName;
    private String productName;




        private String status;

}
