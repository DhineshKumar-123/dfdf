package com.example.application.controller;

import com.example.application.dto.ProductDto;
import com.example.application.dto.OrderDto;
import com.example.application.dto.PaymentDto;
import com.example.application.service.ProductService;
import com.example.application.service.OrderService;
import com.example.application.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/products")
public class ProductController {

    private final ProductService productService;
    private final OrderService orderService;
    private final PaymentService paymentService;




    @GetMapping("/../product/list")
    public String redirectProductList() {
        return "redirect:/products";
    }

    @GetMapping
    public String redirectToList() {
        return "redirect:/products/list";
    }

    @GetMapping("/list")
    public String listProducts(@RequestParam(value = "keyword", required = false) String keyword, Model model) {
        List<ProductDto> products;

        if (keyword != null && !keyword.trim().isEmpty()) {
            products = productService.searchProducts(keyword.trim());
            model.addAttribute("keyword", keyword);
        } else {
            products = productService.getAllProducts();
        }

        model.addAttribute("products", products);
        return "product/list";
    }


    @GetMapping("/view/{id}")
    public String viewProduct(@PathVariable Long id, Model model) {
        ProductDto product = productService.getProductById(id);
        if (product == null) {
            return "error/404";
        }
        model.addAttribute("product", product);
        return "product/view";
    }


    @PostMapping("/order/{productId}")
    public String placeOrder(@PathVariable Long productId,
                             @RequestParam("quantity") int quantity,
                             @AuthenticationPrincipal UserDetails user,
                             Model model) {
        if (user == null) {
            return "redirect:/login";
        }

        orderService.createOrder(user.getUsername(), productId, quantity);
        return "redirect:/products/orders";
    }


    @GetMapping("/orders")
    public String viewOrders(@AuthenticationPrincipal UserDetails user, Model model) {
        if (user == null) {
            return "redirect:/login";
        }

        List<OrderDto> orders = orderService.getOrdersByUser(user.getUsername());
        model.addAttribute("orders", orders);
        return "product/orders";
    }

    @GetMapping("/orders/track/{orderId}")
    public String trackOrder(@PathVariable Long orderId, Model model,
                             @AuthenticationPrincipal UserDetails user) {
        if (user == null) {
            return "redirect:/login";
        }

        OrderDto order = orderService.getOrderById(orderId);
        if (order == null) {
            return "error/404";
        }

        model.addAttribute("order", order);
        return "product/track";
    }

    @GetMapping("/payments")
    public String viewPaymentHistory(@AuthenticationPrincipal UserDetails user, Model model) {
        if (user == null) {
            return "redirect:/login";
        }

        List<PaymentDto> payments = paymentService.getPaymentsByUser(user.getUsername());
        model.addAttribute("payments", payments);
        return "product/payments";
    }


    @GetMapping("/logout")
    public String logout() {

        return "redirect:/logout";
    }
}
