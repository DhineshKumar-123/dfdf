package com.example.application.repository;

import com.example.application.entity.CartItem;

import com.example.application.entity.Product;
import com.example.application.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CartItemRepository extends JpaRepository<CartItem,Long> {
    List<CartItem> findByUser(User user);

    CartItem findByUserAndProduct(User user, Product product);
    List<CartItem> findByUserId(Long userId);

}
