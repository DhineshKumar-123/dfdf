package com.example.application.controller;

import com.example.application.dto.OrderDto;
import com.example.application.dto.PaymentDto;
import com.example.application.entity.User;
import com.example.application.service.OrderService;
import com.example.application.service.PaymentService;
import com.example.application.service.UserService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentService paymentService;
    private final OrderService orderService;
    private final UserService userService;
    private final ModelMapper modelMapper;

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    public PaymentController(PaymentService paymentService,
                             OrderService orderService,
                             UserService userService,
                             ModelMapper modelMapper) {
        this.paymentService = paymentService;
        this.orderService = orderService;
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/create/{orderId}")
    public String createPaymentForm(@PathVariable Long orderId, Model model, Principal principal) {
        OrderDto order = orderService.getOrderById(orderId);
        if (order == null) return "redirect:/orders/view?error=Order+not+found";

        PaymentDto payment = new PaymentDto();
        payment.setOrderId(orderId);
        payment.setAmount(BigDecimal.valueOf(order.getTotalPrice() != null ? order.getTotalPrice() : 0));
        payment.setPaymentStatus("PENDING");

        model.addAttribute("order", order);
        model.addAttribute("payment", payment);
        model.addAttribute("razorpayKeyId", razorpayKeyId);
        return "payment/create";
    }

    @PostMapping("/razorpay")
    @ResponseBody
    public Map<String, Object> createRazorpayOrder(@RequestParam Double amount, Principal principal) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (amount == null || amount <= 0) {
                throw new RuntimeException("Invalid amount specified for payment.");
            }

            BigDecimal upiWalletMax = BigDecimal.valueOf(20000);
            if (BigDecimal.valueOf(amount).compareTo(upiWalletMax) > 0) {
                response.put("error", "Amount exceeds the maximum allowed per transaction for UPI/Wallet payments (" + upiWalletMax + "). Please use card/netbanking or split the payment.");
                return response;
            }

            long amountInPaise = Math.round(amount * 100);

            RazorpayClient razorpay = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amountInPaise);
            orderRequest.put("currency", "INR");
            orderRequest.put("payment_capture", 1);

            Order razorOrder = razorpay.orders.create(orderRequest);

            User user = userService.findByEmail(principal.getName())
                    .orElseThrow(() -> new RuntimeException("User not found"));


            PaymentDto paymentDto = new PaymentDto();
            paymentDto.setRazorpayOrderId(razorOrder.get("id"));
            paymentDto.setPaymentStatus("PENDING");
            paymentDto.setAmount(BigDecimal.valueOf(amount));
            paymentDto.setPaymentMethod("Razorpay");
            paymentDto.setPaymentDate(LocalDateTime.now());
            paymentDto.setUserId(user.getId());

            paymentService.savePayment(paymentDto);

            response.put("razorpayOrderId", razorOrder.get("id"));
            response.put("amount", amountInPaise);
            response.put("currency", "INR");

        } catch (Exception e) {
            response.put("error", e.getMessage());
        }
        return response;
    }
    @PostMapping("/save")
    public String savePayment(
            @RequestParam("razorpay_order_id") String razorpayOrderId,
            @RequestParam("razorpay_payment_id") String razorpayPaymentId,
            @RequestParam("razorpay_signature") String razorpaySignature,
            @RequestParam("orderId") Long orderId,
            @RequestParam("amount") String amount,
            Principal principal,
            RedirectAttributes redirectAttributes) {

        try {
            User user = userService.findByEmail(principal.getName())
                    .orElseThrow(() -> new RuntimeException("User not found"));


            PaymentDto payment = paymentService.findByRazorpayOrderId(razorpayOrderId);
            if (payment == null) {
                payment = new PaymentDto();
            }

            payment.setUserId(user.getId());
            payment.setOrderId(orderId);
            payment.setAmount(new BigDecimal(amount));
            payment.setPaymentStatus("SUCCESS");
            payment.setStatus("PAID");
            payment.setPaymentDate(LocalDateTime.now());
            payment.setPaymentMethod("Razorpay");
            payment.setRazorpayOrderId(razorpayOrderId);
            payment.setRazorpayPaymentId(razorpayPaymentId);
            payment.setRazorpaySignature(razorpaySignature);

            paymentService.savePayment(payment);


            OrderDto order = orderService.getOrderById(orderId);
            if (order != null) {
                order.setOrderStatus("PAID");
                order.setRazorpayOrderId(razorpayOrderId);
                order.setRazorpayPaymentId(razorpayPaymentId);
                order.setRazorpaySignature(razorpaySignature);
                orderService.updateOrder(orderId, order);
            }

            redirectAttributes.addFlashAttribute("payment", payment);
            redirectAttributes.addFlashAttribute("message", "Payment successful!");
            return "redirect:/payments/success";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("message", "Payment failed: " + e.getMessage());
            return "redirect:/payments/failed";
        }
    }

    @GetMapping("/success")
    public String showSuccessPage(@ModelAttribute("payment") PaymentDto payment, Model model) {
        model.addAttribute("payment", payment);
        return "payment/success";
    }



    @GetMapping("/failed")
    public String paymentFailed(Model model) {
        PaymentDto payment = new PaymentDto();
        payment.setRazorpayOrderId("N/A");
        payment.setRazorpayPaymentId("N/A");
        payment.setPaymentStatus("FAILED");
        payment.setAmount(BigDecimal.ZERO);

        model.addAttribute("payment", payment);
        model.addAttribute("message", "Payment failed. Please try again.");

        return "payment/failed";
    }

}


