package com.example.application.service.impl;

import com.example.application.dto.CartItemDto;
import com.example.application.dto.PaymentDto;
import com.example.application.entity.CartItem;
import com.example.application.entity.Order;
import com.example.application.entity.Payment;
import com.example.application.entity.User;
import com.example.application.repository.CartItemRepository;
import com.example.application.repository.OrderRepository;
import com.example.application.repository.PaymentRepository;
import com.example.application.repository.UserRepository;
import com.example.application.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final CartItemRepository cartItemRepository;
    private final PaymentRepository paymentRepository;
    private final ModelMapper modelMapper;
    private final OrderRepository orderRepository;
    private  final UserRepository userRepository;

    @Override
    public PaymentDto createPayment(PaymentDto paymentDto) {
        Payment payment = modelMapper.map(paymentDto, Payment.class);
        return modelMapper.map(paymentRepository.save(payment), PaymentDto.class);
    }

    @Override
    public PaymentDto getPaymentById(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with ID: " + id));
        return modelMapper.map(payment, PaymentDto.class);
    }

    @Override
    public List<PaymentDto> getAllPayments() {
        return paymentRepository.findAll()
                .stream()
                .map(payment -> modelMapper.map(payment, PaymentDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public PaymentDto updatePayment(Long id, PaymentDto paymentDto) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with ID: " + id));
        modelMapper.map(paymentDto, payment);
        if (paymentDto.getUserId() != null) {
            User user = new User();
            user.setId(paymentDto.getUserId());
            payment.setUser(user);
        }
        if (paymentDto.getOrderId() != null) {
            Order order = new Order();
            order.setId(paymentDto.getOrderId());
            payment.setOrder(order);
        }
        return modelMapper.map(paymentRepository.save(payment), PaymentDto.class);
    }

    @Override
    public void deletePayment(Long id) {
        paymentRepository.deleteById(id);
    }

    @Override
    public CartItemDto getCartItemById(Long id) {
        Optional<CartItem> cartItemOpt = cartItemRepository.findById(id);
        return cartItemOpt.map(cartItem -> modelMapper.map(cartItem, CartItemDto.class)).orElse(null);
    }

    @Override
    public List<PaymentDto> getPaymentsByUser(String email) {
        return paymentRepository.findByUserEmail(email)
                .stream()
                .map(payment -> modelMapper.map(payment, PaymentDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public PaymentDto savePayment(PaymentDto paymentDto) {
        Payment paymentEntity = paymentRepository.findByRazorpayOrderId(paymentDto.getRazorpayOrderId());

        if (paymentEntity == null) {
            paymentEntity = new Payment();
        }

        if (paymentDto.getUserId() != null) {
            User user = userRepository.findById(paymentDto.getUserId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            paymentEntity.setUser(user);
        }

        if (paymentDto.getOrderId() != null) {
            Order order = orderRepository.findById(paymentDto.getOrderId())
                    .orElseThrow(() -> new RuntimeException("Order not found"));
            paymentEntity.setOrder(order);
        }


        paymentEntity.setRazorpayOrderId(paymentDto.getRazorpayOrderId());
        paymentEntity.setRazorpayPaymentId(paymentDto.getRazorpayPaymentId());
        paymentEntity.setRazorpaySignature(paymentDto.getRazorpaySignature());
        paymentEntity.setPaymentId(paymentDto.getRazorpayPaymentId());

        paymentEntity.setPaymentStatus(paymentDto.getPaymentStatus() != null ? paymentDto.getPaymentStatus() : "PENDING");
        paymentEntity.setStatus(paymentDto.getStatus() != null ? paymentDto.getStatus() : "PENDING");
        paymentEntity.setPaymentDate(paymentDto.getPaymentDate() != null ? paymentDto.getPaymentDate() : LocalDateTime.now());
        paymentEntity.setPaymentMethod(paymentDto.getPaymentMethod());
        paymentEntity.setAmount(paymentDto.getAmount() != null ? paymentDto.getAmount().doubleValue() : 0);

        Payment saved = paymentRepository.save(paymentEntity);

        return modelMapper.map(saved, PaymentDto.class);
    }

    @Override
    public PaymentDto findByRazorpayOrderId(String razorpayOrderId) {
        Payment payment = paymentRepository.findByRazorpayOrderId(razorpayOrderId);
        return payment != null ? modelMapper.map(payment, PaymentDto.class) : null;
    }
    @Override
    public Map<String, Object> createRazorpayOrder(PaymentDto paymentDto) {
        Map<String, Object> mockResponse = new HashMap<>();
        mockResponse.put("id", "order_123");
        mockResponse.put("amount", paymentDto.getAmount());
        mockResponse.put("currency", "INR");
        return mockResponse;
    }

}
