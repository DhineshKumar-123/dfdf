package com.example.application.config;

import com.example.application.security.CustomSuccessHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    private final CustomSuccessHandler customSuccessHandler;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    	http.csrf(csrf -> csrf.ignoringRequestMatchers("/payments/**"));
http
                .authorizeHttpRequests(auth -> auth

                        .requestMatchers("/", "/home", "/login", "/register",
                                "/css/**", "/js/**", "/images/**", "/uploads/**").permitAll()


                        .requestMatchers("/user/profile/**").hasAnyRole("USER", "ADMIN")
                        .requestMatchers("/user/list", "/user/delete/**", "/user/update/**").hasRole("ADMIN")


                        .requestMatchers("/admin/products/**").hasRole("ADMIN")
                        .requestMatchers("/products/**").hasAnyRole("USER", "ADMIN")


                        .requestMatchers("/cartitem/**").hasRole("USER")


                        .requestMatchers("/orders/create", "/orders/edit/**", "/orders/update/**", "/orders/delete/**").hasAnyRole("USER", "ADMIN")
                        .requestMatchers("/orders", "/orders/**").hasAnyRole("USER", "ADMIN")

                        .requestMatchers("/payment/create", "/payment/view/**").hasRole("USER")
                        .requestMatchers("/payment/list", "/payment/edit/**", "/payment/delete/**").hasRole("ADMIN")


                        .requestMatchers("/admin/**").hasRole("ADMIN")


                        .anyRequest().authenticated()
                )
        .formLogin(form -> form
                .loginPage("/login")
                .loginProcessingUrl("/login")
                .usernameParameter("email")
                .passwordParameter("password")
                .successHandler(customSuccessHandler)
                .permitAll()
        )

        .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                )
                .exceptionHandling(ex -> ex.accessDeniedHandler(accessDeniedHandler()));

        return http.build();
    }

    @Bean
    public AccessDeniedHandler accessDeniedHandler() {
        return (request, response, accessDeniedException) -> response.sendRedirect("/access-denied");
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}









