package com.example.application.controller;

import com.example.application.dto.CartItemDto;
import com.example.application.entity.User;
import com.example.application.service.CartItemService;
import com.example.application.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.security.Principal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class CartItemControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CartItemService cartItemService;

    @MockBean
    private UserService userService;

    private User user;
    private CartItemDto item1;
    private CartItemDto item2;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setId(1L);
        user.setEmail("test@example.com");

        item1 = new CartItemDto();
        item1.setId(1L);
        item1.setProductName("T-Shirt");
        item1.setTotalPrice(2000.0);
        item1.setQuantity(1);

        item2 = new CartItemDto();
        item2.setId(2L);
        item2.setProductName("Jeans");
        item2.setTotalPrice(2500.0);
        item2.setQuantity(2);
    }

    // ✅ 1. Test: viewCartItems (authenticated)
    @Test
    @WithMockUser(username = "test@example.com", roles = {"USER"})
    void viewCartItems_shouldDisplayCartItems() throws Exception {
        List<CartItemDto> cartItems = Arrays.asList(item1, item2);
        when(userService.findByEmail("test@example.com")).thenReturn(Optional.of(user));
        when(cartItemService.getCartItemsByUser(1L)).thenReturn(cartItems);
        when(cartItemService.getTotalAmount(1L)).thenReturn(4500.0);

        mockMvc.perform(get("/cartitems"))
                .andExpect(status().isOk())
                .andExpect(view().name("cartitem/list"))
                .andExpect(model().attributeExists("cartItems"))
                .andExpect(model().attributeExists("totalAmount"));
    }

    // ✅ 2. Test: addToCart
    @Test
    @WithMockUser(username = "test@example.com", roles = {"USER"})
    void addToCart_shouldRedirectToCartItems() throws Exception {
        when(userService.findByEmail("test@example.com")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/cartitems/add/10"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cartitems"));

        verify(cartItemService, times(1)).addToCart(1L, 10L, 1);
    }

    // ✅ 3. Test: updateQuantity
    @Test
    @WithMockUser(username = "test@example.com", roles = {"USER"})
    void updateQuantity_shouldRedirectToCartItems() throws Exception {
        mockMvc.perform(post("/cartitems/update/5")
                        .param("quantity", "3")
                        .with(csrf()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cartitems"));

        verify(cartItemService, times(1)).updateQuantity(5L, 3);
    }

    // ✅ 4. Test: deleteCartItem
    @Test
    @WithMockUser(username = "test@example.com", roles = {"USER"})
    void deleteCartItem_shouldRedirectToCartItems() throws Exception {
        mockMvc.perform(get("/cartitems/delete/5"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cartitems"));

        verify(cartItemService, times(1)).removeFromCart(5L);
    }

    // ✅ 5. Test: checkout
    @Test
    @WithMockUser(username = "test@example.com", roles = {"USER"})
    void checkout_shouldShowCheckoutPage() throws Exception {
        when(userService.findByEmail("test@example.com")).thenReturn(Optional.of(user));
        when(cartItemService.getTotalAmount(1L)).thenReturn(4500.0);

        mockMvc.perform(get("/cartitems/checkout"))
                .andExpect(status().isOk())
                .andExpect(view().name("cartitem/checkout"))
                .andExpect(model().attributeExists("totalAmount"));
    }

    // ✅ 6. Test: increaseQuantity
    @Test
    @WithMockUser(username = "test@example.com", roles = {"USER"})
    void increaseQuantity_shouldRedirectToCartItems() throws Exception {
        mockMvc.perform(get("/cartitems/increase/3"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cartitems"));

        verify(cartItemService, times(1)).increaseQuantity(3L);
    }

    // ✅ 7. Test: decreaseQuantity
    @Test
    @WithMockUser(username = "test@example.com", roles = {"USER"})
    void decreaseQuantity_shouldRedirectToCartItems() throws Exception {
        mockMvc.perform(get("/cartitems/decrease/3"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/cartitems"));

        verify(cartItemService, times(1)).decreaseQuantity(3L);
    }
}
