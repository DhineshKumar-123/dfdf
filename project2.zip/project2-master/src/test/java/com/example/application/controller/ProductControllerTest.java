package com.example.application.controller;

import com.example.application.dto.OrderDto;
import com.example.application.dto.PaymentDto;
import com.example.application.dto.ProductDto;
import com.example.application.service.OrderService;
import com.example.application.service.PaymentService;
import com.example.application.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.ui.Model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ProductControllerTest {

    @Mock
    private ProductService productService;
    @Mock
    private OrderService orderService;
    @Mock
    private PaymentService paymentService;
    @Mock
    private Model model;
    @Mock
    private UserDetails userDetails;

    @InjectMocks
    private ProductController productController;

    private ProductDto sampleProduct;
    private OrderDto sampleOrder;
    private PaymentDto samplePayment;

    @BeforeEach
    void setUp() {
        sampleProduct = new ProductDto();
        sampleProduct.setId(1L);
        sampleProduct.setName("Laptop");
        sampleProduct.setDescription("High-end laptop");
        sampleProduct.setPrice(BigDecimal.valueOf(45000));
        sampleProduct.setStock(5);

        sampleOrder = new OrderDto();
        sampleOrder.setId(10L);
        sampleOrder.setProductId(1L);
        sampleOrder.setOrderStatus("CREATED");

        samplePayment = new PaymentDto();
        samplePayment.setId(100L);
        samplePayment.setAmount(BigDecimal.valueOf(45000));
        samplePayment.setPaymentStatus("PAID");
    }

    // ✅ redirect /../product/list → /products
    @Test
    void testRedirectProductList() {
        String view = productController.redirectProductList();
        assertEquals("redirect:/products", view);
    }

    // ✅ redirect /products → /products/list
    @Test
    void testRedirectToList() {
        String view = productController.redirectToList();
        assertEquals("redirect:/products/list", view);
    }

    // ✅ list all products
    @Test
    void testListProducts_All() {
        List<ProductDto> products = Arrays.asList(sampleProduct);
        when(productService.getAllProducts()).thenReturn(products);

        String view = productController.listProducts(null, model);

        assertEquals("product/list", view);
        verify(model).addAttribute("products", products);
        verify(productService).getAllProducts();
    }

    // ✅ list products by keyword
    @Test
    void testListProducts_WithKeyword() {
        List<ProductDto> filtered = Arrays.asList(sampleProduct);
        when(productService.searchProducts("Laptop")).thenReturn(filtered);

        String view = productController.listProducts("Laptop", model);

        assertEquals("product/list", view);
        verify(model).addAttribute("products", filtered);
        verify(model).addAttribute("keyword", "Laptop");
        verify(productService).searchProducts("Laptop");
    }

    // ✅ view product by id (found)
    @Test
    void testViewProduct_Found() {
        when(productService.getProductById(1L)).thenReturn(sampleProduct);

        String view = productController.viewProduct(1L, model);

        assertEquals("product/view", view);
        verify(model).addAttribute("product", sampleProduct);
    }

    // ❌ view product by id (not found)
    @Test
    void testViewProduct_NotFound() {
        when(productService.getProductById(1L)).thenReturn(null);

        String view = productController.viewProduct(1L, model);

        assertEquals("error/404", view);
    }

    // ✅ place order (user logged in)
    @Test
    void testPlaceOrder_WithUser() {
        when(userDetails.getUsername()).thenReturn("pari@example.com");

        String view = productController.placeOrder(1L, 2, userDetails, model);

        assertEquals("redirect:/products/orders", view);
        verify(orderService).createOrder("pari@example.com", 1L, 2);
    }

    // ❌ place order (no user)
    @Test
    void testPlaceOrder_NoUser() {
        String view = productController.placeOrder(1L, 2, null, model);
        assertEquals("redirect:/login", view);
    }

    // ✅ view orders (user logged in)
    @Test
    void testViewOrders_WithUser() {
        when(userDetails.getUsername()).thenReturn("pari@example.com");
        List<OrderDto> orders = Arrays.asList(sampleOrder);
        when(orderService.getOrdersByUser("pari@example.com")).thenReturn(orders);

        String view = productController.viewOrders(userDetails, model);

        assertEquals("product/orders", view);
        verify(model).addAttribute("orders", orders);
    }

    // ❌ view orders (no user)
    @Test
    void testViewOrders_NoUser() {
        String view = productController.viewOrders(null, model);
        assertEquals("redirect:/login", view);
    }

    @Test
    void testTrackOrder_Success() {
        when(userDetails.getUsername()).thenReturn("pari@example.com");

        // ✅ Create mock order
        OrderDto mockOrder = new OrderDto();
        mockOrder.setId(10L); // <-- correct setter based on your DTO
        mockOrder.setOrderStatus("Delivered");

        when(orderService.getOrderById(10L)).thenReturn(mockOrder);

        String view = productController.trackOrder(10L, model, userDetails);

        assertEquals("product/track", view);
        verify(orderService).getOrderById(10L);
        verify(model).addAttribute("order", mockOrder);
    }



    @Test
    void testTrackOrder_OrderNotFound() {
        // Given - mock a user so that the controller passes the user == null check
        when(userDetails.getUsername()).thenReturn("pari@example.com");

        // lenient stub so Mockito doesn’t complain even if the method isn't called
        lenient().when(orderService.getOrderById(10L)).thenReturn(null);

        // When
        String view = productController.trackOrder(10L, model, userDetails);

        // Then
        assertEquals("error/404", view);
    }



    // ❌ track order (no user)
    @Test
    void testTrackOrder_NoUser() {
        String view = productController.trackOrder(10L, model, null);
        assertEquals("redirect:/login", view);
    }

    // ✅ view payment history (user logged in)
    @Test
    void testViewPaymentHistory_WithUser() {
        when(userDetails.getUsername()).thenReturn("pari@example.com");
        List<PaymentDto> payments = Arrays.asList(samplePayment);
        when(paymentService.getPaymentsByUser("pari@example.com")).thenReturn(payments);

        String view = productController.viewPaymentHistory(userDetails, model);

        assertEquals("product/payments", view);
        verify(model).addAttribute("payments", payments);
    }

    // ❌ view payment history (no user)
    @Test
    void testViewPaymentHistory_NoUser() {
        String view = productController.viewPaymentHistory(null, model);
        assertEquals("redirect:/login", view);
    }

    // ✅ logout redirection
    @Test
    void testLogout() {
        String view = productController.logout();
        assertEquals("redirect:/logout", view);
    }
}
