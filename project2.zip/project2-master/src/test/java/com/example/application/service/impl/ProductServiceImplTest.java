package com.example.application.service.impl;

import com.example.application.dto.ProductDto;
import com.example.application.entity.Product;
import com.example.application.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceImplTest {

    @Mock
    ProductRepository productRepository;

    @Mock
    ModelMapper modelMapper;

    @InjectMocks
    ProductServiceImpl productService;

    Product product;
    ProductDto productDto;

    @BeforeEach
    void setUp() {
        product = new Product();
        product.setId(1L);
        product.setName("X");
        product.setPrice(BigDecimal.valueOf(55));

        productDto = new ProductDto();
        productDto.setName("X");
        productDto.setPrice(BigDecimal.valueOf(55));
    }

    @Test
    void createProduct_withoutImage_setsDefault() {
        when(modelMapper.map(productDto, Product.class)).thenReturn(product);
        when(productRepository.save(product)).thenReturn(product);
        when(modelMapper.map(product, ProductDto.class)).thenReturn(productDto);

        ProductDto out = productService.createProduct(productDto, null);
        assertNotNull(out);
        verify(productRepository).save(product);
    }

    @Test
    void createProduct_withImage_callsSaveAndSetsUrl() throws Exception {
        when(modelMapper.map(productDto, Product.class)).thenReturn(product);
        when(productRepository.save(any())).thenReturn(product);
        when(modelMapper.map(product, ProductDto.class)).thenReturn(productDto);

        MockMultipartFile file = new MockMultipartFile("image", "img.jpg", "image/jpeg", "abc".getBytes());
        ProductDto out = productService.createProduct(productDto, file);
        assertNotNull(out);
        verify(productRepository).save(any());
    }

    @Test
    void updateProductWithImage_whenProductMissing_throws() {
        when(productRepository.findById(5L)).thenReturn(Optional.empty());
        ProductDto dto = new ProductDto();
        RuntimeException ex = assertThrows(RuntimeException.class, () -> productService.updateProductWithImage(5L, dto, null));
        assertTrue(ex.getMessage().contains("Product not found"));
    }

    @Test
    void updateProductWithImage_keepOldImage_whenNoFile() {
        Product existing = new Product();
        existing.setId(2L);
        existing.setImageUrl("/images/old.jpg");
        when(productRepository.findById(2L)).thenReturn(Optional.of(existing));
        ProductDto dto = new ProductDto();
        dto.setName("N");
        dto.setDescription("D");
        dto.setPrice(BigDecimal.valueOf(10));
        dto.setStock(5);

        productService.updateProductWithImage(2L, dto, null);
        assertEquals("/images/old.jpg", existing.getImageUrl());
    }

    @Test
    void updateProduct_basic() {
        Product existing = new Product();
        existing.setId(3L);
        when(productRepository.findById(3L)).thenReturn(Optional.of(existing));
        ProductDto dto = new ProductDto();
        dto.setName("nm");
        dto.setDescription("d");
        dto.setPrice(BigDecimal.valueOf(5));
        dto.setStock(2);
        dto.setQuantity(1);
        dto.setImageUrl("/images/xx.jpg");

        when(productRepository.save(existing)).thenReturn(existing);
        when(modelMapper.map(existing, ProductDto.class)).thenReturn(dto);

        ProductDto out = productService.updateProduct(3L, dto);
        assertNotNull(out);
        verify(productRepository).save(existing);
    }

    @Test
    void getProductById_and_getAllProducts_and_search() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        when(modelMapper.map(product, ProductDto.class)).thenReturn(productDto);
        assertNotNull(productService.getProductById(1L));

        when(productRepository.findAll()).thenReturn(Arrays.asList(product));
        when(modelMapper.map(product, ProductDto.class)).thenReturn(productDto);
        var all = productService.getAllProducts();
        assertEquals(1, all.size());

        when(productRepository.findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCase("kw","kw"))
                .thenReturn(Arrays.asList(product));
        var found = productService.searchProducts("kw");
        assertEquals(1, found.size());
    }

    @Test
    void delete_saveProduct_saveProductImage() throws Exception {
        productService.deleteProduct(8L);
        verify(productRepository).deleteById(8L);

        productService.saveProduct(productDto);
        verify(productRepository).save(any());

        MockMultipartFile file = new MockMultipartFile("f", "a.jpg", "image/jpg", "bytes".getBytes());
        Product p = new Product();
        productService.saveProductImage(file, p);
        assertNotNull(p.getImageUrl());
    }
}
