package com.example.application.service.impl;

import com.example.application.dto.OrderDto;
import com.example.application.entity.Order;
import com.example.application.entity.Product;
import com.example.application.entity.User;
import com.example.application.repository.OrderRepository;
import com.example.application.repository.ProductRepository;
import com.example.application.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceImplTest {

    @Mock
    OrderRepository orderRepository;

    @Mock
    UserRepository userRepository;

    @Mock
    ProductRepository productRepository;

    @Mock
    ModelMapper modelMapper;

    @InjectMocks
    OrderServiceImpl orderService;

    User user;
    Product product;

    @BeforeEach
    void setup() {
        user = new User();
        user.setId(1L);
        user.setEmail("a@b.com");
        user.setName("Tester");

        product = new Product();
        product.setId(2L);
        product.setName("P");
        product.setPrice(BigDecimal.valueOf(50));
    }

    @Test
    void createOrder_nullEmail_shouldThrow() {
        OrderDto dto = new OrderDto();
        dto.setUserEmail(null);
        dto.setProductId(2L);
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> orderService.createOrder(dto));
        assertTrue(ex.getMessage().contains("User email is required"));
    }

    @Test
    void createOrder_nullProduct_shouldThrow() {
        OrderDto dto = new OrderDto();
        dto.setUserEmail("a@b.com");
        dto.setProductId(null);
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> orderService.createOrder(dto));
        assertTrue(ex.getMessage().contains("Product ID is required"));
    }

    @Test
    void createOrder_success() {
        OrderDto dto = new OrderDto();
        dto.setUserEmail("a@b.com");
        dto.setProductId(2L);
        dto.setQuantity(2);
        dto.setOrderStatus("CREATED");

        when(userRepository.findByEmail("a@b.com")).thenReturn(Optional.of(user));
        when(productRepository.findById(2L)).thenReturn(Optional.of(product));

        Order saved = new Order();
        saved.setId(10L);
        saved.setUser(user);
        saved.setProduct(product);
        saved.setQuantity(2);
        saved.setTotalPrice(100.0);
        saved.setAmount(BigDecimal.valueOf(100));
        saved.setOrderStatus("CREATED");
        saved.setDate(LocalDateTime.now());

        when(orderRepository.save(any())).thenReturn(saved);

        OrderDto result = orderService.createOrder(dto);

        assertNotNull(result);
        assertEquals(10L, result.getId());
        assertEquals("a@b.com", result.getUserEmail());
    }

    @Test
    void getOrderById_returnsMappedOrNull() {
        Order o = new Order();
        o.setId(5L);
        when(orderRepository.findById(5L)).thenReturn(Optional.of(o));
        OrderDto dto = new OrderDto();
        when(modelMapper.map(o, OrderDto.class)).thenReturn(dto);

        assertNotNull(orderService.getOrderById(5L));
        when(orderRepository.findById(6L)).thenReturn(Optional.empty());
        assertNull(orderService.getOrderById(6L));
    }

    @Test
    void getAllOrders_mapsList() {
        Order o = new Order();
        o.setId(1L);
        o.setOrderStatus("CREATED");
        o.setTotalPrice(10.0);
        o.setQuantity(1);
        o.setDate(LocalDateTime.now());
        o.setUser(user);
        o.setProduct(product);
        when(orderRepository.findAll()).thenReturn(Collections.singletonList(o));

        var list = orderService.getAllOrders();
        assertEquals(1, list.size());
        assertEquals("CREATED", list.get(0).getOrderStatus());
    }

    @Test
    void cancelOrder_and_deleteOrder() {
        Order o = new Order();
        o.setId(20L);
        o.setOrderStatus("CREATED");
        when(orderRepository.findById(20L)).thenReturn(Optional.of(o));

        orderService.cancelOrder(20L);
        assertEquals("CANCELLED", o.getOrderStatus());
        verify(orderRepository).save(o);

        when(orderRepository.existsById(99L)).thenReturn(false);
        RuntimeException ex = assertThrows(RuntimeException.class, () -> orderService.deleteOrder(99L));
        assertTrue(ex.getMessage().contains("Order not found"));
    }

    @Test
    void getOrdersByProductId_and_byUser() {
        Order o = new Order();
        when(orderRepository.findOrdersByProductId(2L)).thenReturn(Arrays.asList(o));
        when(modelMapper.map(o, OrderDto.class)).thenReturn(new OrderDto());
        var res = orderService.getOrdersByProductId(2L);
        assertEquals(1, res.size());

        when(orderRepository.findByUserEmail("x")).thenReturn(Arrays.asList(o));
        when(modelMapper.map(o, OrderDto.class)).thenReturn(new OrderDto());
        var res2 = orderService.getOrdersByUser("x");
        assertEquals(1, res2.size());
    }

    @Test
    void isOrderOwnedByUser_trueFalse() {
        Order o = new Order();
        o.setId(7L);
        o.setUser(user);
        when(orderRepository.findById(7L)).thenReturn(Optional.of(o));
        assertTrue(orderService.isOrderOwnedByUser(7L, "a@b.com"));
        assertFalse(orderService.isOrderOwnedByUser(7L, "other@b.com"));
    }

    @Test
    void updateOrderStatus_notFound_shouldThrow() {
        when(orderRepository.findById(50L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> orderService.updateOrderStatus(50L, "S"));
        assertTrue(ex.getMessage().contains("Order not found"));
    }

    @Test
    void createOrder_byEmailVariant_callsCreate() {
        Order saved = new Order();
        saved.setId(30L);
        when(userRepository.findByEmail(anyString())).thenReturn(Optional.of(user));
        when(productRepository.findById(anyLong())).thenReturn(Optional.of(product));
        when(orderRepository.save(any())).thenReturn(saved);

        orderService.createOrder("a@b.com", 2L, 1);
        verify(orderRepository).save(any());
    }

    @Test
    void updateOrderPaymentDetails_success() {
        Order o = new Order();
        o.setId(77L);
        when(orderRepository.findById(77L)).thenReturn(Optional.of(o));
        orderService.updateOrderPaymentDetails(77L, "pay", "ord", "sign");
        assertEquals("PAID", o.getOrderStatus());
        assertEquals("pay", o.getRazorpayPaymentId());
        verify(orderRepository).save(o);
    }

    @Test
    void findExistingUnpaidOrder_and_findByRazorpay() {
        Order o = new Order();
        o.setUser(user);
        o.setProduct(product);
        o.setOrderStatus("CREATED");
        when(orderRepository.findAll()).thenReturn(Arrays.asList(o));
        when(modelMapper.map(o, OrderDto.class)).thenReturn(new OrderDto());

        var res = orderService.findExistingUnpaidOrder("a@b.com", 2L);
        assertNotNull(res);

        when(orderRepository.findByRazorpayOrderId("rId")).thenReturn(Optional.of(o));
        when(modelMapper.map(o, OrderDto.class)).thenReturn(new OrderDto());
        var res2 = orderService.findByRazorpayOrderId("rId");
        assertNotNull(res2);
    }

    @Test
    void updateOrder_recalculatesTotal() {
        Order existing = new Order();
        existing.setId(100L);
        existing.setProduct(product);
        existing.setQuantity(1);
        existing.getProduct().setPrice(BigDecimal.valueOf(5));
        when(orderRepository.findById(100L)).thenReturn(Optional.of(existing));

        OrderDto dto = new OrderDto();
        dto.setQuantity(3);
        dto.setOrderStatus("SENT");

        orderService.updateOrder(100L, dto);
        assertEquals(3, existing.getQuantity());
        assertEquals(15.0, existing.getTotalPrice());
        verify(orderRepository).save(existing);
    }
}
