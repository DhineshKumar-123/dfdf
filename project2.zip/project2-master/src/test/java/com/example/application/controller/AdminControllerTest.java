package com.example.application.controller;

import com.example.application.dto.OrderDto;
import com.example.application.dto.ProductDto;
import com.example.application.dto.UserDto;
import com.example.application.service.OrderService;
import com.example.application.service.ProductService;
import com.example.application.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AdminController.class)
@AutoConfigureMockMvc(addFilters = false)
class AdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;
    @MockBean
    private ProductService productService;
    @MockBean
    private OrderService orderService;

    private UserDto userDto;
    private ProductDto productDto;
    private OrderDto orderDto;

    @BeforeEach
    void setup() {
        userDto = new UserDto();
        userDto.setId(1L);
        userDto.setName("John");

        productDto = new ProductDto();
        productDto.setId(1L);
        productDto.setName("T-Shirt");

        orderDto = new OrderDto();
        orderDto.setId(1L);
        orderDto.setOrderStatus("CREATED");
    }

    @Test
    void viewAllOrders_shouldReturnOrdersView() throws Exception {
        Mockito.when(orderService.getAllOrders()).thenReturn(Collections.singletonList(orderDto));

        mockMvc.perform(get("/admin/orders"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/orders"))
                .andExpect(model().attributeExists("orders"));
    }

    @Test
    void deleteOrder_shouldRedirectToOrdersList() throws Exception {
        doNothing().when(orderService).deleteOrder(1L);

        mockMvc.perform(get("/admin/orders/delete/1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/orders"));
    }

    @Test
    void viewAllProducts_shouldReturnProductsView() throws Exception {
        Mockito.when(productService.getAllProducts()).thenReturn(Collections.singletonList(productDto));

        mockMvc.perform(get("/admin/products"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/products"))
                .andExpect(model().attributeExists("products"));
    }

    @Test
    void deleteProduct_shouldRedirectToProductList() throws Exception {
        doNothing().when(productService).deleteProduct(1L);

        mockMvc.perform(get("/admin/products/delete/1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/products"));
    }

    @Test
    void viewAllUsers_shouldReturnUsersView() throws Exception {
        Mockito.when(userService.findAll()).thenReturn(Collections.singletonList(userDto));

        mockMvc.perform(get("/admin/users"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/users"))
                .andExpect(model().attributeExists("users"));
    }

    @Test
    void editUser_whenNotFound_shouldShowErrorPage() throws Exception {
        Mockito.when(userService.findById(anyLong())).thenReturn(null);

        mockMvc.perform(get("/admin/users/edit/99"))
                .andExpect(status().isOk())
                .andExpect(view().name("error/404"));
    }
}
