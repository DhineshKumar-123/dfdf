package com.example.application.controller;

import com.example.application.dto.OrderDto;
import com.example.application.dto.PaymentDto;
import com.example.application.entity.User;
import com.example.application.service.OrderService;
import com.example.application.service.PaymentService;
import com.example.application.service.UserService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

//@WebMvcTest(PaymentController.class)
@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(PaymentController.class)
class PaymentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private PaymentController paymentController;

    @MockBean
    private PaymentService paymentService;

    @MockBean
    private OrderService orderService;

    @MockBean
    private UserService userService;

    @MockBean
    private ModelMapper modelMapper;

    private OrderDto orderDto;
    private User user;
    private Principal principal;

    @BeforeEach
    void setUp() {
        principal = () -> "pari@example.com";

        user = new User();
        user.setId(1L);
        user.setName("Pari");
        user.setEmail("pari@example.com");

        orderDto = new OrderDto();
        orderDto.setId(1L);
        orderDto.setTotalPrice(1500.0);

        ReflectionTestUtils.setField(paymentController, "razorpayKeyId", "test_key_id");
        ReflectionTestUtils.setField(paymentController, "razorpayKeySecret", "test_key_secret");
    }


    @Test
    @WithMockUser
    void testCreatePaymentForm_OrderNotFound_ShouldRedirect() throws Exception {
        when(orderService.getOrderById(1L)).thenReturn(null);

        mockMvc.perform(get("/payments/create/1").principal(principal))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/orders/view?error=Order+not+found"));
    }

    @Test
    @WithMockUser
    void testCreateRazorpayOrder_Success() throws Exception {
        // Arrange
        when(userService.findByEmail(anyString())).thenReturn(Optional.of(user));
        when(paymentService.savePayment(any(PaymentDto.class))).thenReturn(new PaymentDto());

        com.razorpay.Order fakeOrder = Mockito.mock(com.razorpay.Order.class);
        when(fakeOrder.get("id")).thenReturn("order_123");

        com.razorpay.OrderClient fakeOrderClient = Mockito.mock(com.razorpay.OrderClient.class);
        when(fakeOrderClient.create(Mockito.any(org.json.JSONObject.class))).thenReturn(fakeOrder);

        try (MockedConstruction<RazorpayClient> mocked = Mockito.mockConstruction(
                RazorpayClient.class,
                (mock, context) -> {
                    // 👇 inject our fake order client into RazorpayClient mock
                    // instead of "when(mock.orders)" — just assign directly
                    mock.orders = fakeOrderClient;
                })) {

            // Act + Assert
            mockMvc.perform(post("/payments/razorpay")
                            .with(csrf())
                            .param("amount", "500.0")
                            .principal(principal)
                            .contentType(MediaType.APPLICATION_FORM_URLENCODED))
                    .andExpect(status().isOk())
                    .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                    .andExpect(jsonPath("$.razorpayOrderId").value("order_123"))
                    .andExpect(jsonPath("$.amount").value(50000))
                    .andExpect(jsonPath("$.currency").value("INR"));
        }

        // Verify interactions
        verify(paymentService).savePayment(any(PaymentDto.class));
        verify(userService).findByEmail(anyString());
    }



    @Test
    @WithMockUser
    void testCreateRazorpayOrder_InvalidAmount() throws Exception {
        mockMvc.perform(post("/payments/razorpay")
                        .with(csrf()) // ✅ CSRF token added
                        .param("amount", "-50.0")
                        .principal(principal)
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.error").exists());
    }

    @Test
    @WithMockUser
    void testSavePayment_Success() throws Exception {
        when(userService.findByEmail(anyString())).thenReturn(Optional.of(user));
        when(paymentService.findByRazorpayOrderId(anyString())).thenReturn(null);
        when(orderService.getOrderById(1L)).thenReturn(orderDto);
        when(paymentService.savePayment(any(PaymentDto.class))).thenReturn(new PaymentDto());
        doNothing().when(orderService).updateOrder(anyLong(), any(OrderDto.class));

        mockMvc.perform(post("/payments/save")
                        .with(csrf()) // ✅ CSRF token added
                        .principal(principal)
                        .param("razorpay_order_id", "order_123")
                        .param("razorpay_payment_id", "pay_456")
                        .param("razorpay_signature", "sig_789")
                        .param("orderId", "1")
                        .param("amount", "1500.0"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/payments/success"));

        verify(paymentService, times(1)).savePayment(any(PaymentDto.class));
        verify(orderService, times(1)).updateOrder(eq(1L), any(OrderDto.class));
    }

    @Test
    @WithMockUser
    void testSavePayment_Failure_UserNotFound() throws Exception {
        when(userService.findByEmail(anyString())).thenReturn(Optional.empty());

        mockMvc.perform(post("/payments/save")
                        .with(csrf()) // ✅ CSRF token added
                        .principal(principal)
                        .param("razorpay_order_id", "order_123")
                        .param("razorpay_payment_id", "pay_456")
                        .param("razorpay_signature", "sig_789")
                        .param("orderId", "1")
                        .param("amount", "1500.0"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/payments/failed"));
    }

    @Test
    @WithMockUser
    void testShowSuccessPage() throws Exception {
        PaymentDto paymentDto = new PaymentDto();
        paymentDto.setAmount(BigDecimal.valueOf(500.0));
        paymentDto.setPaymentStatus("SUCCESS");

        mockMvc.perform(get("/payments/success")
                        .flashAttr("payment", paymentDto))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("payment"))
                .andExpect(view().name("payment/success"));
    }

    @Test
    @WithMockUser
    void testPaymentFailed() throws Exception {
        mockMvc.perform(get("/payments/failed"))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("payment"))
                .andExpect(model().attributeExists("message"))
                .andExpect(view().name("payment/failed"));
    }
}
