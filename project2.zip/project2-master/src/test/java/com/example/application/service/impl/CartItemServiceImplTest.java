package com.example.application.service.impl;

import com.example.application.dto.CartItemDto;
import com.example.application.entity.CartItem;
import com.example.application.entity.Product;
import com.example.application.entity.User;
import com.example.application.repository.CartItemRepository;
import com.example.application.repository.ProductRepository;
import com.example.application.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CartItemServiceImplTest {

    @Mock
    CartItemRepository cartItemRepository;

    @Mock
    ProductRepository productRepository;

    @Mock
    UserRepository userRepository;

    @Mock
    ModelMapper modelMapper;

    @InjectMocks
    CartItemServiceImpl cartItemService;

    private User user;
    private Product product;

    @BeforeEach
    void setUp() {
        user = new User();
        user.setId(1L);

        product = new Product();
        product.setId(2L);
        product.setPrice(BigDecimal.valueOf(100));
        product.setName("TestProduct");
    }

    @Test
    void addToCart_whenUserNotFound_shouldThrow() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> cartItemService.addToCart(1L, 2L, 1));
        assertTrue(ex.getMessage().contains("User not found"));
    }

    @Test
    void addToCart_whenProductNotFound_shouldThrow() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(productRepository.findById(2L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> cartItemService.addToCart(1L, 2L, 1));
        assertTrue(ex.getMessage().contains("Product not found"));
    }

    @Test
    void addToCart_whenNewItem_shouldSaveAndReturnDto() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(productRepository.findById(2L)).thenReturn(Optional.of(product));
        when(cartItemRepository.findByUserAndProduct(user, product)).thenReturn(null);

        CartItem saved = new CartItem();
        saved.setId(10L);
        saved.setUser(user);
        saved.setProduct(product);
        saved.setQuantity(2);
        saved.setTotalPrice(BigDecimal.valueOf(200));
        when(cartItemRepository.save(any())).thenReturn(saved);

        CartItemDto dto = new CartItemDto();
        dto.setId(10L);
        when(modelMapper.map(any(CartItem.class), eq(CartItemDto.class))).thenReturn(dto);


        CartItemDto response = cartItemService.addToCart(1L, 2L, 2);

        assertNotNull(response);
        assertEquals(10L, response.getId());
        verify(cartItemRepository, times(1)).save(any(CartItem.class));
    }

    @Test
    void addToCart_whenExistingItem_shouldIncreaseQuantity() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(productRepository.findById(2L)).thenReturn(Optional.of(product));

        CartItem existing = new CartItem();
        existing.setId(11L);
        existing.setUser(user);
        existing.setProduct(product);
        existing.setQuantity(1);
        existing.setTotalPrice(BigDecimal.valueOf(100));

        when(cartItemRepository.findByUserAndProduct(user, product)).thenReturn(existing);
        when(cartItemRepository.save(existing)).thenReturn(existing);

        CartItemDto mapped = new CartItemDto();
        when(modelMapper.map(existing, CartItemDto.class)).thenReturn(mapped);

        CartItemDto result = cartItemService.addToCart(1L, 2L, 2);

        assertNotNull(result);
        assertEquals(3, existing.getQuantity());
        assertEquals(BigDecimal.valueOf(300).doubleValue(), existing.getTotalPrice().doubleValue());
        verify(cartItemRepository).save(existing);
    }

    @Test
    void getCartItemsByUser_success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        CartItem item = new CartItem();
        item.setId(1L);
        item.setProduct(product);
        item.setUser(user);
        item.setQuantity(2);
        item.setTotalPrice(BigDecimal.valueOf(200));
        when(cartItemRepository.findByUser(user)).thenReturn(Arrays.asList(item));

        CartItemDto dto = new CartItemDto();
        when(modelMapper.map(item, CartItemDto.class)).thenReturn(dto);

        List<CartItemDto> list = cartItemService.getCartItemsByUser(1L);

        assertEquals(1, list.size());
        verify(cartItemRepository).findByUser(user);
    }

    @Test
    void getTotalAmount_success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        CartItem a = new CartItem(); a.setTotalPrice(BigDecimal.valueOf(10));
        CartItem b = new CartItem(); b.setTotalPrice(BigDecimal.valueOf(20));
        when(cartItemRepository.findByUser(user)).thenReturn(Arrays.asList(a, b));

        double total = cartItemService.getTotalAmount(1L);
        assertEquals(30.0, total, 0.001);
    }

    @Test
    void updateQuantity_success() {
        CartItem item = new CartItem();
        item.setId(5L);
        item.setProduct(product);
        item.setQuantity(1);
        when(cartItemRepository.findById(5L)).thenReturn(Optional.of(item));

        cartItemService.updateQuantity(5L, 4);

        assertEquals(4, item.getQuantity());
        assertEquals(BigDecimal.valueOf(400).doubleValue(), item.getTotalPrice().doubleValue());
        verify(cartItemRepository).save(item);
    }

    @Test
    void updateQuantity_cartItemNotFound_shouldThrow() {
        when(cartItemRepository.findById(99L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> cartItemService.updateQuantity(99L, 2));
        assertTrue(ex.getMessage().contains("Cart item not found"));
    }

    @Test
    void removeFromCart_callsDelete() {
        cartItemService.removeFromCart(7L);
        verify(cartItemRepository).deleteById(7L);
    }

    @Test
    void clearCart_success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        CartItem i1 = new CartItem();
        when(cartItemRepository.findByUser(user)).thenReturn(Arrays.asList(i1));
        cartItemService.clearCart(1L);
        verify(cartItemRepository).deleteAll(anyList());
    }

    @Test
    void getCartItemById_returnsDtoOrNull() {
        CartItem item = new CartItem();
        item.setId(2L);
        when(cartItemRepository.findById(2L)).thenReturn(Optional.of(item));
        CartItemDto dto = new CartItemDto();
        when(modelMapper.map(item, CartItemDto.class)).thenReturn(dto);

        CartItemDto res = cartItemService.getCartItemById(2L);
        assertNotNull(res);

        when(cartItemRepository.findById(3L)).thenReturn(Optional.empty());
        assertNull(cartItemService.getCartItemById(3L));
    }

    @Test
    void increaseDecreaseQuantity_behavior() {
        CartItem item = new CartItem();
        item.setId(3L);
        item.setProduct(product);
        item.setQuantity(1);
        when(cartItemRepository.findById(3L)).thenReturn(Optional.of(item));

        cartItemService.increaseQuantity(3L);
        assertEquals(2, item.getQuantity());
        verify(cartItemRepository).save(item);


        cartItemService.decreaseQuantity(3L);
        assertEquals(1, item.getQuantity());
        verify(cartItemRepository, times(2)).save(item);


        when(cartItemRepository.findById(3L)).thenReturn(Optional.of(item));
        item.setQuantity(1);
        cartItemService.decreaseQuantity(3L);
        verify(cartItemRepository).delete(item);
    }

    @Test
    void increaseQuantity_whenNotFound_shouldThrow() {
        when(cartItemRepository.findById(99L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> cartItemService.increaseQuantity(99L));
        assertTrue(ex.getMessage().contains("Cart item not found"));
    }
}
