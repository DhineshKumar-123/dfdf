package com.example.application.service.impl;

import com.example.application.dto.CartItemDto;
import com.example.application.dto.PaymentDto;
import com.example.application.entity.CartItem;
import com.example.application.entity.Order;
import com.example.application.entity.Payment;
import com.example.application.entity.User;
import com.example.application.repository.CartItemRepository;
import com.example.application.repository.OrderRepository;
import com.example.application.repository.PaymentRepository;
import com.example.application.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class PaymentServiceImplTest {
    @Mock
    CartItemRepository cartItemRepository;
    @Mock
    PaymentRepository paymentRepository;
    @Mock
    ModelMapper modelMapper;
    @Mock
    OrderRepository orderRepository;
    @Mock
    UserRepository userRepository;

    @InjectMocks
    PaymentServiceImpl paymentService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void createPayment_mapsAndReturns() {
        PaymentDto dto = new PaymentDto();
        Payment saved = new Payment();
        saved.setId(1L);
        when(modelMapper.map(dto, Payment.class)).thenReturn(new Payment());
        when(paymentRepository.save(any())).thenReturn(saved);
        when(modelMapper.map(saved, PaymentDto.class)).thenReturn(dto);

        PaymentDto result = paymentService.createPayment(dto);
        assertNotNull(result);
        verify(paymentRepository).save(any());
    }

    @Test
    void getPaymentById_found() {
        Payment p = new Payment();
        p.setId(5L);
        when(paymentRepository.findById(5L)).thenReturn(Optional.of(p));
        PaymentDto dto = new PaymentDto();
        when(modelMapper.map(p, PaymentDto.class)).thenReturn(dto);

        PaymentDto out = paymentService.getPaymentById(5L);
        assertNotNull(out);
    }

    @Test
    void getPaymentById_notFound_shouldThrow() {
        when(paymentRepository.findById(99L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> paymentService.getPaymentById(99L));
        assertTrue(ex.getMessage().contains("Payment not found"));
    }

    @Test
    void getAllPayments_returnsList() {
        Payment p = new Payment();
        when(paymentRepository.findAll()).thenReturn(Arrays.asList(p));
        when(modelMapper.map(p, PaymentDto.class)).thenReturn(new PaymentDto());
        var all = paymentService.getAllPayments();
        assertEquals(1, all.size());
    }

    @Test
    void updatePayment_updatesUserAndOrderAndSaves() {
        Payment existing = new Payment();
        when(paymentRepository.findById(1L)).thenReturn(Optional.of(existing));

        PaymentDto dto = new PaymentDto();
        dto.setUserId(2L);
        dto.setOrderId(3L);

        when(modelMapper.map(any(PaymentDto.class), eq(Payment.class)))
                .thenReturn(new Payment());
        when(modelMapper.map(any(Payment.class), eq(PaymentDto.class)))
                .thenReturn(new PaymentDto());

        when(paymentRepository.save(any(Payment.class)))
                .thenReturn(existing);

        PaymentDto out = paymentService.updatePayment(1L, dto);

        assertNotNull(out);
        verify(paymentRepository).save(any(Payment.class));
    }



    @Test
    void deletePayment_callsRepo() {
        paymentService.deletePayment(9L);
        verify(paymentRepository).deleteById(9L);
    }

    @Test
    void getCartItemById_mappingOrNull() {
        CartItem ci = new CartItem();
        when(cartItemRepository.findById(2L)).thenReturn(Optional.of(ci));
        when(modelMapper.map(ci, CartItemDto.class)).thenReturn(new CartItemDto());
        assertNotNull(paymentService.getCartItemById(2L));
        when(cartItemRepository.findById(3L)).thenReturn(Optional.empty());
        assertNull(paymentService.getCartItemById(3L));
    }

    @Test
    void getPaymentsByUser_maps() {
        Payment p = new Payment();
        when(paymentRepository.findByUserEmail("a")).thenReturn(Arrays.asList(p));
        when(modelMapper.map(p, PaymentDto.class)).thenReturn(new PaymentDto());
        var list = paymentService.getPaymentsByUser("a");
        assertEquals(1, list.size());
    }

    @Test
    void savePayment_newPayment_userOrOrderNotFoundThrows() {
        PaymentDto dto1 = new PaymentDto();
        dto1.setRazorpayOrderId("r1");
        dto1.setUserId(100L);
        when(paymentRepository.findByRazorpayOrderId("r1")).thenReturn(null);
        when(userRepository.findById(100L)).thenReturn(Optional.empty());

        RuntimeException ex1 = assertThrows(RuntimeException.class, () -> paymentService.savePayment(dto1));
        assertTrue(ex1.getMessage().contains("User not found"));

        PaymentDto dto2 = new PaymentDto();
        dto2.setRazorpayOrderId("r2");
        dto2.setUserId(1L);
        dto2.setOrderId(200L);

        when(paymentRepository.findByRazorpayOrderId("r2")).thenReturn(null);
        when(userRepository.findById(1L)).thenReturn(Optional.of(new User()));
        when(orderRepository.findById(200L)).thenReturn(Optional.empty());

        RuntimeException ex2 = assertThrows(RuntimeException.class, () -> paymentService.savePayment(dto2));
        assertTrue(ex2.getMessage().contains("Order not found"));
    }


    @Test
    void savePayment_existingAndMapping() {
        Payment p = new Payment();
        when(paymentRepository.findByRazorpayOrderId("r2")).thenReturn(p);
        when(orderRepository.findById(anyLong())).thenReturn(Optional.of(new Order()));
        when(userRepository.findById(anyLong())).thenReturn(Optional.of(new User()));
        when(paymentRepository.save(any())).thenReturn(p);
        PaymentDto dto = new PaymentDto();
        dto.setRazorpayOrderId("r2");
        dto.setUserId(1L);
        dto.setOrderId(2L);
        dto.setPaymentStatus("DONE");
        dto.setStatus("OK");
        dto.setPaymentMethod("CARD");
        dto.setAmount(BigDecimal.valueOf(123));

        when(modelMapper.map(p, PaymentDto.class)).thenReturn(dto);
        PaymentDto out = paymentService.savePayment(dto);
        assertNotNull(out);
    }

    @Test
    void findByRazorpayOrderId_returnsDtoOrNull() {
        when(paymentRepository.findByRazorpayOrderId("x")).thenReturn(null);
        assertNull(paymentService.findByRazorpayOrderId("x"));
        Payment p = new Payment();
        when(paymentRepository.findByRazorpayOrderId("y")).thenReturn(p);
        when(modelMapper.map(p, PaymentDto.class)).thenReturn(new PaymentDto());
        assertNotNull(paymentService.findByRazorpayOrderId("y"));
    }
}
