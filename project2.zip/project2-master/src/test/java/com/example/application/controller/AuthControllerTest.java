package com.example.application.controller;

import com.example.application.dto.UserDto;
import com.example.application.entity.User;
import com.example.application.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.Optional;
import org.springframework.security.web.csrf.DefaultCsrfToken;


import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
@AutoConfigureMockMvc(addFilters = false)
@Import(AuthControllerTest.TestConfig.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @MockBean
    private ModelMapper modelMapper;

    @MockBean
    private PasswordEncoder passwordEncoder;

    private UserDto userDto;

    @BeforeEach
    void setup() {
        userDto = new UserDto();
        userDto.setEmail("test@example.com");
        userDto.setPassword("password");
    }

    static class TestConfig {
        @Bean
        public ViewResolver viewResolver() {
            InternalResourceViewResolver resolver = new InternalResourceViewResolver();
            resolver.setPrefix("/templates/");
            resolver.setSuffix(".html");
            return resolver;
        }
    }

    @Test
    void testShowLoginPage() throws Exception {
        mockMvc.perform(get("/login").with(csrf()))
                .andExpect(status().isOk())
                .andExpect(view().name("auth/login"));
    }

    @Test
    void testShowRegisterForm() throws Exception {
        var csrf = new DefaultCsrfToken("X-CSRF-TOKEN", "_csrf", "dummy-token");

        mockMvc.perform(get("/register").requestAttr("_csrf", csrf))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("user"))
                .andExpect(view().name("auth/register"));
    }


    @Test
    void testRegisterUser_Success() throws Exception {
        when(userService.findByEmail(anyString())).thenReturn(Optional.empty());
        doNothing().when(userService).saveUser(any(UserDto.class));

        mockMvc.perform(post("/register").flashAttr("user", userDto).with(csrf()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?registered=true"));

        verify(userService, times(1)).saveUser(any(UserDto.class));
    }

    @Test
    void testRegisterUser_EmailAlreadyExists() throws Exception {
        when(userService.findByEmail(anyString())).thenReturn(Optional.of(new User()));

        mockMvc.perform(post("/register").flashAttr("user", userDto).with(csrf()))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("error"))
                .andExpect(view().name("auth/register"));
    }

    @Test
    void testRegisterUser_Exception() throws Exception {
        when(userService.findByEmail(anyString())).thenReturn(Optional.empty());
        doThrow(new RuntimeException("Database error")).when(userService).saveUser(any(UserDto.class));

        mockMvc.perform(post("/register").flashAttr("user", userDto).with(csrf()))
                .andExpect(status().isOk())
                .andExpect(model().attributeExists("error"))
                .andExpect(view().name("auth/register"));
    }
}
