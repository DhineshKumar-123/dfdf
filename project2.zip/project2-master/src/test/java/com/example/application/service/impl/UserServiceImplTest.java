package com.example.application.service.impl;

import com.example.application.dto.UserDto;
import com.example.application.entity.User;
import com.example.application.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    UserRepository userRepository;

    @Mock
    ModelMapper modelMapper;

    @Mock
    PasswordEncoder passwordEncoder;

    @InjectMocks
    UserServiceImpl userService;

    UserDto dto;
    User user;

    @BeforeEach
    void setUp() {
        dto = new UserDto();
        dto.setEmail("a@b.com");
        dto.setName("Name");
        dto.setPassword("pwd");

        user = new User();
        user.setId(1L);
        user.setEmail("a@b.com");
        user.setName("Name");
    }

    @Test
    void createUser_whenEmailExists_shouldThrow() {
        when(userRepository.findByEmail("a@b.com")).thenReturn(Optional.of(user));
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> userService.createUser(dto));
        assertTrue(ex.getMessage().contains("Email already registered"));
    }

    @Test
    void createUser_success() {
        when(userRepository.findByEmail("a@b.com")).thenReturn(Optional.empty());
        when(modelMapper.map(dto, User.class)).thenReturn(user);
        when(passwordEncoder.encode("pwd")).thenReturn("encoded");
        when(userRepository.save(user)).thenReturn(user);
        when(modelMapper.map(user, UserDto.class)).thenReturn(dto);

        UserDto out = userService.createUser(dto);
        assertNotNull(out);
        verify(userRepository).save(user);
    }

    @Test
    void updateUser_notFound_shouldThrow() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> userService.updateUser(99L, dto));
        assertTrue(ex.getMessage().contains("User not found"));
    }

    @Test
    void updateUser_success_changesRoleAndPassword() {
        User existing = new User();
        existing.setId(2L);
        existing.setEmail("old@b.com");
        when(userRepository.findById(2L)).thenReturn(Optional.of(existing));
        when(passwordEncoder.encode("newpwd")).thenReturn("enc");
        UserDto upd = new UserDto();
        upd.setName("New");
        upd.setEmail("new@b.com");
        upd.setRole("admin");
        upd.setPassword("newpwd");

        when(userRepository.save(existing)).thenReturn(existing);
        when(modelMapper.map(existing, UserDto.class)).thenReturn(upd);

        UserDto out = userService.updateUser(2L, upd);
        assertNotNull(out);
        assertEquals("ADMIN", existing.getRole());
        verify(userRepository).save(existing);
    }

    @Test
    void deleteUser_callsRepo() {
        userService.deleteUser(10L);
        verify(userRepository).deleteById(10L);
    }

    @Test
    void findByEmail_forwarded() {
        when(userRepository.findByEmail("a@b.com")).thenReturn(Optional.of(user));
        Optional<User> out = userService.findByEmail("a@b.com");
        assertTrue(out.isPresent());
    }

    @Test
    void saveUser_encodesPasswordAndSaves() {
        UserDto in = new UserDto();
        in.setName("N");
        in.setEmail("e@e.com");
        in.setPassword("pass");
        when(passwordEncoder.encode("pass")).thenReturn("enc");
        userService.saveUser(in);
        verify(userRepository).save(any());
    }

    @Test
    void findAll_and_findById_and_getAllUsers() {
        when(userRepository.findAll()).thenReturn(Arrays.asList(user));
        var all = userService.findAll();
        assertEquals(1, all.size());

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(modelMapper.map(user, UserDto.class)).thenReturn(dto);
        UserDto out = userService.findById(1L);
        assertNotNull(out);

        var getAll = userService.getAllUsers();
        assertEquals(all.size(), getAll.size());
    }

    @Test
    void findById_notFound_shouldThrow() {
        when(userRepository.findById(500L)).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> userService.findById(500L));
        assertTrue(ex.getMessage().contains("User not found"));
    }
}
