package com.example.application.controller;

import com.example.application.dto.OrderDto;
import com.example.application.dto.PaymentDto;
import com.example.application.dto.ProductDto;
import com.example.application.entity.User;
import com.example.application.service.OrderService;
import com.example.application.service.PaymentService;
import com.example.application.service.ProductService;
import com.example.application.service.UserService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.Authentication;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class OrderControllerUnitTest {

    private OrderController orderController;

    private OrderService orderService;
    private ProductService productService;
    private UserService userService;
    private PaymentService paymentService;
    private ModelMapper modelMapper;

    private User user;
    private ProductDto product;
    private OrderDto order;
    private PaymentDto payment;

    @BeforeEach
    void setup() throws Exception {
        // Mock all dependencies
        orderService = mock(OrderService.class);
        productService = mock(ProductService.class);
        userService = mock(UserService.class);
        paymentService = mock(PaymentService.class);
        modelMapper = mock(ModelMapper.class);

        // Create controller with mocks
        orderController = new OrderController(orderService, productService, userService, modelMapper, paymentService);

        // Set private @Value fields using reflection
        Field keyField = OrderController.class.getDeclaredField("razorpayKeyId");
        keyField.setAccessible(true);
        keyField.set(orderController, "test_key_id");

        Field secretField = OrderController.class.getDeclaredField("razorpayKeySecret");
        secretField.setAccessible(true);
        secretField.set(orderController, "test_key_secret");

        // Sample data
        user = new User();
        user.setId(1L);
        user.setEmail("test@example.com");
        user.setName("Test User");

        product = new ProductDto();
        product.setId(1L);
        product.setName("Laptop");
        product.setPrice(BigDecimal.valueOf(1000));

        order = new OrderDto();
        order.setId(10L);
        order.setProductId(1L);
        order.setProductName("Laptop");
        order.setUserEmail("test@example.com");
        order.setUserName("Test User");
        order.setQuantity(2);
        order.setTotalPrice(2000.0);
        order.setOrderStatus("CREATED");

        payment = new PaymentDto();
        payment.setId(1L);
        payment.setAmount(BigDecimal.valueOf(2000));
        payment.setPaymentStatus("PENDING");
        payment.setRazorpayOrderId("razor_123");
    }

    // -------------------------------
    // Unit tests (all mocked, no HTTP)
    // -------------------------------

    @Test
    void testDefaultRedirect() {
        String view = orderController.defaultRedirect();
        assertEquals("redirect:/orders/view", view);
    }

    @Test
    void testShowCreateOrderForm_Success() {
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("test@example.com");
        when(productService.getProductById(1L)).thenReturn(product);
        when(userService.findByEmail("test@example.com")).thenReturn(Optional.of(user));

        var model = mock(org.springframework.ui.Model.class);

        String view = orderController.showCreateOrderForm(1L, 2, model, auth);
        assertEquals("order/create", view);

        verify(model).addAttribute(eq("order"), any(OrderDto.class));
        verify(model).addAttribute(eq("product"), eq(product));
    }

    @Test
    void testShowCreateOrderForm_ProductNotFound() {
        Authentication auth = mock(Authentication.class);
        when(productService.getProductById(1L)).thenReturn(null);
        var model = mock(org.springframework.ui.Model.class);

        String view = orderController.showCreateOrderForm(1L, 1, model, auth);
        assertEquals("redirect:/products/list?error=Product+not+found", view);
    }

    @Test
    void testViewOrders_Success() {
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("test@example.com");
        when(orderService.getOrdersByUserEmail("test@example.com")).thenReturn(List.of(order));
        var model = mock(org.springframework.ui.Model.class);

        String view = orderController.viewOrders(model, auth);
        assertEquals("order/list", view);
        verify(model).addAttribute("orders", List.of(order));
    }

    @Test
    void testViewOrderDetails_Success() {
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("test@example.com");
        when(orderService.getOrderById(10L)).thenReturn(order);
        when(productService.getProductById(1L)).thenReturn(product);

        var model = mock(org.springframework.ui.Model.class);
        String view = orderController.viewOrderDetails(10L, model, auth);
        assertEquals("order/view", view);
        verify(model).addAttribute("order", order);
        verify(model).addAttribute("product", product);
    }

    @Test
    void testViewOrderDetails_NotFound() {
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("test@example.com");
        when(orderService.getOrderById(10L)).thenReturn(null);

        var model = mock(org.springframework.ui.Model.class);
        String view = orderController.viewOrderDetails(10L, model, auth);
        assertEquals("redirect:/orders/view", view);
    }

    @Test
    void testCancelOrder_Success() {
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("test@example.com");
        when(orderService.isOrderOwnedByUser(10L, "test@example.com")).thenReturn(true);

        var redirectAttributes = mock(org.springframework.web.servlet.mvc.support.RedirectAttributes.class);

        String view = orderController.cancelOrder(10L, auth, redirectAttributes);
        assertEquals("redirect:/orders/view", view);
        verify(orderService).updateOrderStatus(10L, "CANCELLED");
        verify(redirectAttributes).addFlashAttribute("success", "Order cancelled successfully!");
    }

    @Test
    void testCancelOrder_Unauthorized() {
        Authentication auth = mock(Authentication.class);
        when(auth.getName()).thenReturn("test@example.com");
        when(orderService.isOrderOwnedByUser(10L, "test@example.com")).thenReturn(false);

        var redirectAttributes = mock(org.springframework.web.servlet.mvc.support.RedirectAttributes.class);

        String view = orderController.cancelOrder(10L, auth, redirectAttributes);
        assertEquals("redirect:/orders/view", view);
        verify(orderService, never()).updateOrderStatus(anyLong(), anyString());
        verify(redirectAttributes).addFlashAttribute("error", "Unauthorized: You cannot cancel this order.");
    }

    // You can add more tests for createRazorpayOrder() and confirmPayment() similarly,
    // just mock RazorpayClient, Order, and PaymentDto.
}
