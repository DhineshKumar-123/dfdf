package com.example.application.controller;

import com.example.application.dto.UserDto;
import com.example.application.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(UserController.class)
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @Test
    @WithMockUser(username = "testuser") // Simulates an authenticated user
    void testViewProfile() throws Exception {
        Mockito.when(userService.getUserById(anyLong()))
                .thenReturn(new UserDto());

        mockMvc.perform(get("/users/profile/1"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "testuser")
    void testEditProfile() throws Exception {
        Mockito.when(userService.getUserById(anyLong()))
                .thenReturn(new UserDto());

        mockMvc.perform(get("/users/profile/edit/1"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "testuser")
    void testUpdateProfile() throws Exception {
        mockMvc.perform(post("/users/profile/update/1")
                        .param("name", "Updated User")
                        .param("email", "updated@example.com")
                        .with(csrf())) // Include CSRF token
                .andExpect(status().is3xxRedirection());
    }
}
