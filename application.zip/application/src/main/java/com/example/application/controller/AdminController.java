package com.example.application.controller;

import com.example.application.dto.ProductDto;
import com.example.application.dto.UserDto;
import com.example.application.service.ProductService;
import com.example.application.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import java.util.List;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;
    private final ProductService productService;

    // -------------------- DASHBOARD --------------------
    @GetMapping({"/", "/home"})
    public String adminHome() {
        return "admin/dashboard";
    }



    @GetMapping("/orders")
    public String adminOrders(Model model) {
        return "admin/orders";
    }

    // -------------------- USERS --------------------
    @GetMapping("/users")
    public String listUsers(Model model) {
        List<UserDto> usersList = userService.findAll();
        model.addAttribute("users", usersList);
        return "admin/users";
    }

    // -------------------- PRODUCTS --------------------
    @GetMapping("/products")
    public String listProducts(Model model) {
        List<ProductDto> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "admin/products";
    }

    @GetMapping("/products/create")
    public String showCreateForm(Model model) {
        model.addAttribute("product", new ProductDto());
        return "admin/create";
    }

    // ✅ CREATE PRODUCT (delegates file saving to ProductServiceImpl)
    @PostMapping("/products/create")
    public String createProduct(@ModelAttribute ProductDto productDto,
                                @RequestParam("imageFile") MultipartFile imageFile,
                                Model model) {
        try {
            productService.createProduct(productDto, imageFile);
            return "redirect:/admin/products";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Failed to create product: " + e.getMessage());
            return "admin/create";
        }
    }

    // -------------------- EDIT PRODUCT --------------------
    @GetMapping("/products/edit/{id}")
    public String editProduct(@PathVariable Long id, Model model) {
        ProductDto product = productService.getProductById(id);
        if (product == null) {
            return "error/404";
        }
        model.addAttribute("product", product);
        return "admin/edit";
    }

    @PostMapping("/products/update/{id}")
    public String updateProduct(@PathVariable Long id,
                                @ModelAttribute ProductDto productDto,
                                @RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
                                Model model) {
        try {
            productService.updateProductWithImage(id, productDto, imageFile);
            return "redirect:/admin/products";
        } catch (RuntimeException e) {
            model.addAttribute("error", "Could not update product: " + e.getMessage());
            model.addAttribute("product", productDto);
            return "admin/edit";
        }
    }

    // -------------------- DELETE PRODUCT --------------------
    @GetMapping("/products/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return "redirect:/admin/products";
    }
}
