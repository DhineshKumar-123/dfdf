package com.example.application.controller;

import com.example.application.dto.CartItemDto;
import com.example.application.dto.OrderDto;
import com.example.application.dto.PaymentDto;
import com.example.application.entity.Payment;
import com.example.application.entity.User;
import com.example.application.service.CartItemService;
import com.example.application.service.OrderService;
import com.example.application.service.PaymentService;
import com.example.application.service.UserService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentService paymentService;
    private final OrderService orderService;
    private final CartItemService cartItemService;
    private final UserService userService;
    private final ModelMapper modelMapper;

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    public PaymentController(PaymentService paymentService,
                             OrderService orderService,
                             CartItemService cartItemService,
                             UserService userService,
                             ModelMapper modelMapper) {
        this.paymentService = paymentService;
        this.orderService = orderService;
        this.cartItemService = cartItemService;
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    // ✅ List all payments
    @GetMapping
    public String listPayments(Model model) {
        List<PaymentDto> payments = paymentService.getAllPayments()
                .stream()
                .map(p -> modelMapper.map(p, PaymentDto.class))
                .collect(Collectors.toList());
        model.addAttribute("payments", payments);
        return "payment/list";
    }

    // ✅ Show payment form for an order
    @GetMapping("/create/{orderId}")
    public String createPaymentForm(@PathVariable Long orderId, Model model) {
        OrderDto order = orderService.getOrderById(orderId);
        if (order == null) {
            return "redirect:/orders/view?error=Order+not+found";
        }

        PaymentDto payment = new PaymentDto();
        payment.setOrderId(orderId);
        payment.setAmount(order.getTotalPrice() != null ?
                BigDecimal.valueOf(order.getTotalPrice()) : BigDecimal.ZERO);
        payment.setPaymentStatus("PENDING");

        model.addAttribute("order", order);
        model.addAttribute("payment", payment);
        model.addAttribute("razorpayKeyId", razorpayKeyId);
        return "payment/create";
    }

    // ✅ Checkout from cart
    @GetMapping("/checkout")
    public String checkoutFromCart(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login?error=Please+login+to+checkout";
        }

        Optional<User> userOpt = userService.findByEmail(principal.getName());
        if (userOpt.isEmpty()) {
            return "redirect:/login?error=User+not+found";
        }

        User user = userOpt.get();
        List<CartItemDto> cartItems = cartItemService.getCartItemsByUser(user.getId());
        double totalAmount = cartItemService.getTotalAmount(user.getId());

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalAmount", totalAmount);
        model.addAttribute("razorpayKeyId", razorpayKeyId);
        return "cartitem/checkout";
    }

    // ✅ Create Razorpay order (AJAX)
    @PostMapping("/razorpay")
    @ResponseBody
    public Map<String, Object> createRazorpayOrder(@RequestParam Double amount) {
        Map<String, Object> response = new HashMap<>();
        try {
            int amountInPaise = (int) (amount * 100);
            if (amountInPaise < 100) {
                throw new IllegalArgumentException("Amount must be at least ₹1.00");
            }

            RazorpayClient razorpay = new RazorpayClient(razorpayKeyId, razorpayKeySecret);

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amountInPaise);
            orderRequest.put("currency", "INR");
            orderRequest.put("payment_capture", 1);

            Order razorOrder = razorpay.orders.create(orderRequest);

            response.put("id", razorOrder.get("id"));
            response.put("amount", amountInPaise);
            response.put("currency", "INR");
        } catch (Exception e) {
            response.put("error", e.getMessage());
        }
        return response;
    }

    // ✅ Save payment after successful payment (fixed version)
    @PostMapping("/save")
    public String savePayment(
            @RequestParam("orderId") String orderId,
            @RequestParam("paymentId") String paymentId,
            @RequestParam("amount") String amount,
            @RequestParam("status") String status,
            RedirectAttributes redirectAttributes) {

        try {
            PaymentDto payment = new PaymentDto();
            payment.setRazorpayOrderId(orderId);
            payment.setRazorpayPaymentId(paymentId);
            payment.setPaymentStatus(status);
            payment.setAmount(new BigDecimal(amount));
            payment.setPaymentMethod("Razorpay");
            payment.setPaymentDate(LocalDateTime.now());

            // ✅ Save to DB
            paymentService.savePayment(payment);

            redirectAttributes.addFlashAttribute("message", "Payment successful!");
            redirectAttributes.addFlashAttribute("payment", payment);
            return "redirect:/payments/success";
//            return "payment/success";

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("message", "Payment failed: " + e.getMessage());
            return "redirect:/payments/failed";
//            return "payment/failed";
        }
    }

    @RequestMapping(value = "/success", method = {RequestMethod.GET, RequestMethod.POST})	
    public String showSuccessPage(@RequestParam(required = false) String orderId,
                                  @RequestParam(required = false) String paymentId,
                                  @RequestParam(required = false) String signature,
                                  Model model) {

        Payment payment = new Payment();
        payment.setRazorpayOrderId(orderId);
        payment.setRazorpayPaymentId(paymentId);
        payment.setRazorpaySignature(signature);
        payment.setStatus("SUCCESS");

        model.addAttribute("payment", payment);
        return "payment/success";  // looks for templates/payment/success.html
    }


    @RequestMapping(value = "/failed", method = {RequestMethod.GET, RequestMethod.POST})
    public String paymentFailed(Model model) {
        Payment payment = new Payment(); // or your model class
        payment.setRazorpayOrderId("N/A");
        model.addAttribute("payment", payment);
        return "payment/failed";
    }


    // ✅ Redirect for invalid URL
    @GetMapping("/create")
    public String redirectToOrders() {
        return "redirect:/orders/view?error=Please+select+an+order+to+pay";
    }

    // ✅ View payment details
    @GetMapping("/view/{id}")
    public String viewPayment(@PathVariable Long id, Model model) {
        PaymentDto payment = paymentService.getPaymentById(id);
        if (payment == null) {
            return "redirect:/payments?error=Payment+not+found";
        }
        model.addAttribute("payment", payment);
        return "payment/view";
    }

    // ✅ Delete payment
    @GetMapping("/delete/{id}")
    public String deletePayment(@PathVariable Long id) {
        paymentService.deletePayment(id);
        return "redirect:/payments?success=Deleted+successfully";
    }

    // ✅ Payment for a single cart item
    @GetMapping("/create/cart/{cartItemId}")
    public String createPaymentForCartItem(@PathVariable Long cartItemId, Model model) {
        CartItemDto cartItem = cartItemService.getCartItemById(cartItemId);
        if (cartItem == null) {
            model.addAttribute("error", "Cart item not found!");
            return "redirect:/cartitems";
        }

        PaymentDto payment = new PaymentDto();
        payment.setAmount(cartItem.getTotalPrice() != null ? cartItem.getTotalPrice() : BigDecimal.ZERO);
        payment.setPaymentStatus("PENDING");
        payment.setOrderId(cartItem.getId());

        model.addAttribute("payment", payment);
        model.addAttribute("cartItem", cartItem);
        model.addAttribute("razorpayKeyId", razorpayKeyId);
        return "payment/create";
    }
}
