package com.example.application.service;

import com.example.application.dto.CartItemDto;
import com.example.application.entity.CartItem;

import java.util.List;

public interface CartItemService {

//    CartItemDto createCartItem(CartItemDto cartItemDto);
//    CartItemDto getCartItemById(Long id);
//    List<CartItemDto> getAllCartItems();
//    CartItemDto updateCartItem(Long id, CartItemDto cartItemDto);
//    void deleteCartItem(Long id);

//    CartItemDto addToCart(Long userId, Long productId, int quantity);
//    List<CartItemDto> getCartItemsByUser(Long userId);
//    void updateQuantity(Long cartItemId, int quantity);
//    void removeFromCart(Long id);
//    void clearCart(Long userId);
//    double getTotalAmount(Long userId);

    CartItemDto addToCart(Long userId, Long productId, int quantity);
    List<CartItemDto> getCartItemsByUser(Long userId);
    double getTotalAmount(Long userId);
    void clearCart(Long userId);
    void updateQuantity(Long cartItemId, int quantity);
    void removeFromCart(Long cartItemId);

    CartItemDto getCartItemById(Long id);
    void increaseQuantity(Long id);
    void decreaseQuantity(Long id);
}
