package com.example.application.controller;

import com.example.application.dto.OrderDto;
import com.example.application.dto.ProductDto;
import com.example.application.entity.User;
import com.example.application.service.OrderService;
import com.example.application.service.ProductService;
import com.example.application.service.UserService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/orders")
public class OrderController {

    private final OrderService orderService;
    private final ProductService productService;
    private final UserService userService;
    private final ModelMapper modelMapper;

    @Value("${razorpay.key.id}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret}")
    private String razorpayKeySecret;

    @Autowired
    public OrderController(OrderService orderService,
                           ProductService productService,
                           UserService userService,
                           ModelMapper modelMapper) {
        this.orderService = orderService;
        this.productService = productService;
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    /** ✅ Default redirect */
    @GetMapping
    public String defaultRedirect() {
        return "redirect:/orders/view";
    }

    /** ✅ Step 1: Show order creation form */
    @GetMapping("/create")
    public String showCreateOrderForm(@RequestParam("productId") Long productId,
                                      Model model,
                                      Authentication authentication) {
        ProductDto product = productService.getProductById(productId);
        if (product == null) {
            return "redirect:/products/list?error=Product+not+found";
        }

        String email = authentication.getName();
        User user = userService.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        OrderDto orderDto = new OrderDto();
        orderDto.setProductId(product.getId());
        orderDto.setProductName(product.getName());
        orderDto.setUserEmail(user.getEmail());
        orderDto.setUserName(user.getName());

        // ✅ Safely convert BigDecimal → Double
        Double price = (product.getPrice() != null) ? product.getPrice().doubleValue() : 0.0;
        orderDto.setTotalPrice(price);

        orderDto.setOrderStatus("CREATED");

        model.addAttribute("order", orderDto);
        model.addAttribute("product", product);
        return "order/create"; // ✅ templates/order/create.html
    }


    @PostMapping("/pay")
    public String createRazorpayOrder(@ModelAttribute("order") OrderDto orderDto,
                                      Model model,
                                      Authentication authentication) {
        try {
            String email = authentication.getName();
            User user = userService.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            RazorpayClient razorpay = new RazorpayClient(razorpayKeyId, razorpayKeySecret);

            // Convert total price (Double) → paise (int)
            Double totalAmount = orderDto.getTotalPrice() != null ? orderDto.getTotalPrice() : 0.0;
            BigDecimal amountInPaise = BigDecimal.valueOf(totalAmount * 100);

            JSONObject options = new JSONObject();
            options.put("amount", amountInPaise.intValue()); // amount in paise
            options.put("currency", "INR");
            options.put("receipt", "order_rcpt_" + System.currentTimeMillis());

            Order razorpayOrder = razorpay.orders.create(options);

            model.addAttribute("razorpayOrderId", razorpayOrder.get("id"));
            model.addAttribute("razorpayKeyId", razorpayKeyId);
            model.addAttribute("amount", totalAmount);
            model.addAttribute("currency", "INR");
            model.addAttribute("order", orderDto);
            model.addAttribute("user", user);
//            System.out.println("Razorpay Key ID: " + razorpayKeyId);
//            System.out.println("Razorpay Key Secret: " + razorpayKeySecret);


            return "payment/create"; // ✅ templates/payment/create.html
        } catch (Exception e) {
            model.addAttribute("error", "Error creating Razorpay order: " + e.getMessage());
            return "error";
        }
    }

    /** ✅ Step 3: Confirm order after successful payment */
    @PostMapping("/confirm")
    public String confirmPayment(@RequestParam("razorpay_payment_id") String paymentId,
                                 @RequestParam("razorpay_order_id") String razorOrderId,
                                 @RequestParam("razorpay_signature") String signature,
                                 @ModelAttribute("order") OrderDto orderDto,
                                 Authentication authentication,
                                 Model model) {
        try {
            String email = authentication.getName();
            User user = userService.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            orderDto.setUserEmail(user.getEmail());
            orderDto.setOrderStatus("PAID");

            orderService.createOrder(orderDto);

            model.addAttribute("order", orderDto);
            model.addAttribute("message", "Payment successful!");
            return "order/success"; // ✅ templates/order/success.html
        } catch (Exception e) {
            model.addAttribute("error", "Payment failed: " + e.getMessage());
            return "order/failure"; // ✅ templates/order/failure.html
        }
    }

    /** ✅ Step 4: View all orders of the logged-in user */
    @GetMapping("/view")
    public String viewOrders(Model model, Authentication authentication) {
        try {
            String email = authentication.getName();
            User user = userService.findByEmail(email).orElse(null);

            if (user != null) {
                List<OrderDto> orders = orderService.getAllOrders().stream()
                        .filter(o -> o.getUserEmail().equals(user.getEmail()))
                        .peek(o -> {
                            ProductDto product = productService.getProductById(o.getProductId());
                            if (product != null) {
                                o.setProduct(product);
                                o.setProductName(product.getName());

                                // ✅ Convert BigDecimal → Double safely
                                Double price = (product.getPrice() != null)
                                        ? product.getPrice().doubleValue()
                                        : 0.0;
                                o.setTotalPrice(price);
                            }
                        })
                        .collect(Collectors.toList());

                model.addAttribute("orders", orders);
            } else {
                model.addAttribute("error", "User not found!");
            }
        } catch (Exception e) {
            model.addAttribute("error", "Error fetching orders: " + e.getMessage());
        }

        return "order/list"; // ✅ templates/order/list.html
    }

    /** ✅ Step 5: View single order details */
    @GetMapping("/details/{id}")
    public String viewOrderDetails(@PathVariable Long id,
                                   Model model,
                                   Authentication authentication) {
        if (authentication == null) {
            return "redirect:/login";
        }

        String email = authentication.getName();
        OrderDto order = orderService.getOrderById(id);

        if (order == null) {
            model.addAttribute("errorMessage", "Order not found");
            return "redirect:/orders/list";
        }

        ProductDto product = productService.getProductById(order.getProductId());
        if (product != null) {
            order.setProduct(product);
            order.setProductName(product.getName());

            // ✅ Fix: Convert BigDecimal → Double safely
            Double price = (product.getPrice() != null)
                    ? product.getPrice().doubleValue()
                    : 0.0;
            order.setTotalPrice(price);
        }

        model.addAttribute("order", order);
        model.addAttribute("product", product);
        model.addAttribute("razorpayKeyId", razorpayKeyId);

        return "order/view"; // ✅ templates/order/view.html
    }

    /** ✅ Step 6: Delete an order */
    @GetMapping("/delete/{id}")
    public String deleteOrder(@PathVariable Long id, Authentication authentication) {
        try {
            String username = authentication.getName();
            if (orderService.isOrderOwnedByUser(id, username)) {
                orderService.deleteOrder(id);
                return "redirect:/orders/view?success=Order+deleted+successfully";
            } else {
                return "redirect:/orders/view?error=Unauthorized";
            }
        } catch (Exception e) {
            return "redirect:/orders/view?error=" + e.getMessage();
        }
    }

    /** ✅ Step 7: Dedicated list endpoint for compatibility */
    @GetMapping("/list")
    public String showOrderList(Model model, Authentication authentication) {
        if (authentication == null) {
            return "redirect:/login";
        }

        String email = authentication.getName();
        List<OrderDto> orders = orderService.getOrdersByUserEmail(email);

        model.addAttribute("orders", orders);
        return "order/list";  // ✅ templates/order/list.html
    }
}



//temporary payment implemented
//package com.example.application.controller;
//
//import com.example.application.dto.OrderDto;
//import com.example.application.dto.ProductDto;
//import com.example.application.service.OrderService;
//import com.example.application.service.ProductService;
//import lombok.RequiredArgsConstructor;
//import org.json.JSONObject;
//import org.springframework.security.core.Authentication;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//        import java.util.List;
//
//@Controller
//@RequiredArgsConstructor
//@RequestMapping("/orders")
//public class OrderController {
//
//    private final ProductService productService;
//    private final OrderService orderService;
//
//    // =====================================
//    // 🛒 STEP 1: Show Order Creation Page
//    // =====================================
//    @GetMapping("/create")
//    public String showCreateOrderForm(@RequestParam("productId") Long productId,
//                                      Model model,
//                                      Authentication authentication) {
//
//        if (authentication == null || !authentication.isAuthenticated()) {
//            return "redirect:/login";
//        }
//
//        ProductDto product = productService.getProductById(productId);
//        if (product == null) {
//            return "error/404";
//        }
//
//        // Build Order DTO
//        OrderDto orderDto = new OrderDto();
//        orderDto.setProductId(product.getId());
//        orderDto.setProductName(product.getName());
//        orderDto.setPrice(product.getPrice());
//        orderDto.setEmail(authentication.getName());
//        orderDto.setStatus("CREATED");
//
//        // ✅ Save the order immediately (for testing)
//        orderService.createOrder(orderDto);
//
//        model.addAttribute("product", product);
//        model.addAttribute("order", orderDto);
//        return "order/create"; // templates/order/create.html
//    }
//
//    // =====================================
//    // 💳 STEP 2: Mock Payment (No Razorpay)
//    // =====================================
//    @PostMapping("/pay")
//    public String mockPayment(@RequestParam("orderId") Long orderId,
//                              @RequestParam("amount") Double amount,
//                              Model model) {
//
//        // ✅ Simulate successful Razorpay order creation
//        JSONObject razorpayOrder = new JSONObject();
//        razorpayOrder.put("id", "test_order_" + System.currentTimeMillis());
//        razorpayOrder.put("amount", amount.intValue() * 100);
//
//        model.addAttribute("razorpayOrderId", razorpayOrder.getString("id"));
//        model.addAttribute("amount", amount);
//        model.addAttribute("orderId", orderId);
//
//        return "order/payment"; // templates/order/payment.html
//    }
//
//    // =====================================
//    // ✅ STEP 3: Confirm Order (After Payment)
//    // =====================================
//    @PostMapping("/confirm")
//    public String confirmOrder(@RequestParam("orderId") Long orderId,
//                               @RequestParam("paymentId") String paymentId,
//                               Model model) {
//
//        // Update order status
//        orderService.updateOrderStatus(orderId, "PAID", paymentId);
//
//        model.addAttribute("message", "Payment successful! Order confirmed.");
//        return "order/success"; // templates/order/success.html
//    }
//
//    // =====================================
//    // 📦 STEP 4: View User Orders
//    // =====================================
//    @GetMapping("/view")
//    public String viewOrders(Model model, Authentication authentication) {
//        if (authentication == null || !authentication.isAuthenticated()) {
//            return "redirect:/login";
//        }
//
//        String email = authentication.getName();
//        List<OrderDto> orders = orderService.getOrdersByUser(email);
//        model.addAttribute("orders", orders);
//
//        return "order/view"; // templates/order/view.html
//    }
//
//    // =====================================
//    // 🚚 STEP 5: Track Order
//    // =====================================
//    @GetMapping("/track/{id}")
//    public String trackOrder(@PathVariable Long id, Model model, Authentication authentication) {
//        if (authentication == null || !authentication.isAuthenticated()) {
//            return "redirect:/login";
//        }
//
//        OrderDto order = orderService.getOrderById(id);
//        if (order == null) {
//            return "error/404";
//        }
//
//        model.addAttribute("order", order);
//        return "order/track"; // templates/order/track.html
//    }
//}
