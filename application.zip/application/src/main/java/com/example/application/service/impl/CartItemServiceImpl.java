package com.example.application.service.impl;

import com.example.application.dto.CartItemDto;
import com.example.application.entity.CartItem;
import com.example.application.entity.Product;
import com.example.application.entity.User;
import com.example.application.repository.CartItemRepository;
import com.example.application.repository.ProductRepository;
import com.example.application.repository.UserRepository;
import com.example.application.service.CartItemService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CartItemServiceImpl implements CartItemService {

    private final CartItemRepository cartItemRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public CartItemServiceImpl(CartItemRepository cartItemRepository,
                               ProductRepository productRepository,
                               UserRepository userRepository,
                               ModelMapper modelMapper) {
        this.cartItemRepository = cartItemRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public CartItemDto addToCart(Long userId, Long productId, int quantity) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // Check if item already exists
        CartItem existing = cartItemRepository.findByUserAndProduct(user, product);
        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + quantity);
            existing.setTotalPrice(product.getPrice()
                    .multiply(BigDecimal.valueOf(existing.getQuantity())));
            cartItemRepository.save(existing);
            return modelMapper.map(existing, CartItemDto.class);
        }

        CartItem item = new CartItem();
        item.setUser(user);
        item.setProduct(product);
        item.setQuantity(quantity);
        item.setTotalPrice(product.getPrice().multiply(BigDecimal.valueOf(quantity)));

        cartItemRepository.save(item);

        CartItemDto dto = modelMapper.map(item, CartItemDto.class);
        dto.setProductName(product.getName());
        dto.setProductPrice(product.getPrice());
        return dto;
    }

    @Override
    public List<CartItemDto> getCartItemsByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return cartItemRepository.findByUser(user)
                .stream()
                .map(item -> {
                    CartItemDto dto = modelMapper.map(item, CartItemDto.class);
                    dto.setProductName(item.getProduct().getName());
                    dto.setProductPrice(item.getProduct().getPrice());
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Override
    public double getTotalAmount(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return cartItemRepository.findByUser(user)
                .stream()
                .map(item -> item.getTotalPrice().doubleValue())
                .reduce(0.0, Double::sum);
    }

    @Override
    public void updateQuantity(Long cartItemId, int quantity) {
        CartItem item = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));
        item.setQuantity(quantity);
        item.setTotalPrice(item.getProduct().getPrice().multiply(BigDecimal.valueOf(quantity)));
        cartItemRepository.save(item);
    }


    public void removeFromCart(Long cartItemId) {
        cartItemRepository.deleteById(cartItemId);
    }
    @Override
    public void clearCart(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        List<CartItem> items = cartItemRepository.findByUser(user);
        cartItemRepository.deleteAll(items);
    }
    public CartItemDto getCartItemById(Long id) {
        Optional<CartItem> cartItemOpt = cartItemRepository.findById(id);
        if (cartItemOpt.isEmpty()) {
            return null;
        }
        return modelMapper.map(cartItemOpt.get(), CartItemDto.class);
    }

    @Override
    public void increaseQuantity(Long id) {
        CartItem cartItem = cartItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));

        cartItem.setQuantity(cartItem.getQuantity() + 1);
        cartItem.setTotalPrice(
                cartItem.getProduct().getPrice().multiply(BigDecimal.valueOf(cartItem.getQuantity()))
        );
        cartItemRepository.save(cartItem);
    }

    @Override
    public void decreaseQuantity(Long id) {
        CartItem cartItem = cartItemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));

        if (cartItem.getQuantity() > 1) {
            cartItem.setQuantity(cartItem.getQuantity() - 1);
            cartItem.setTotalPrice(
                    cartItem.getProduct().getPrice().multiply(BigDecimal.valueOf(cartItem.getQuantity()))
            );
            cartItemRepository.save(cartItem);
        } else {
            // if quantity is 1, remove item from cart
            cartItemRepository.delete(cartItem);
        }
    }


}
