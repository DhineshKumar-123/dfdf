package com.example.application.service.impl;

import com.example.application.dto.OrderDto;
import com.example.application.entity.Order;
import com.example.application.entity.Product;
import com.example.application.entity.User;
import com.example.application.repository.OrderRepository;
import com.example.application.repository.ProductRepository;
import com.example.application.repository.UserRepository;
import com.example.application.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public OrderDto createOrder(OrderDto orderDto) {
        Order order = modelMapper.map(orderDto, Order.class);

        // 🔹 Find user by email
        User user = userRepository.findByEmail(orderDto.getUserEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));
        order.setUser(user);

        // 🔹 Find product by ID
        Product product = productRepository.findById(orderDto.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));
        order.setProduct(product);

        // 🔹 Set additional fields
        order.setStatus("CREATED");
        order.setDate(LocalDateTime.now());
        order.setQuantity(orderDto.getQuantity());

        // 🔹 Save and return DTO
        return modelMapper.map(orderRepository.save(order), OrderDto.class);
    }

    @Override
    public OrderDto getOrderById(Long id) {
        return orderRepository.findById(id)
                .map(order -> modelMapper.map(order, OrderDto.class))
                .orElse(null);
    }

    @Override
    public List<OrderDto> getAllOrders() {
        return orderRepository.findAll()
                .stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public OrderDto updateOrder(Long id, OrderDto orderDto) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        modelMapper.map(orderDto, order);
        return modelMapper.map(orderRepository.save(order), OrderDto.class);
    }

    @Override
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    @Override
    public List<OrderDto> getOrdersByProductId(Long productId) {
        return orderRepository.findOrdersByProductId(productId)
                .stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public boolean isOrderOwnedByUser(Long orderId, String email) {
        Optional<Order> order = orderRepository.findById(orderId);
        return order.isPresent() && order.get().getUser().getEmail().equals(email);
    }

    @Override
    public void updateOrderStatus(Long orderId, String status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));

        order.setStatus(status);
        orderRepository.save(order);
    }

    // ✅ Add this helper method (not in interface, but useful for controller)
    public void createOrder(String email, Long productId, int quantity) {
        OrderDto orderDto = new OrderDto();
        orderDto.setUserEmail(email);
        orderDto.setProductId(productId);
        orderDto.setQuantity(quantity);
        createOrder(orderDto);
    }

    @Override
    public List<OrderDto> getOrdersByUser(String email) {
        return orderRepository.findByUserEmail(email)
                .stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .collect(Collectors.toList());
    }
    @Override
    public List<OrderDto> getOrdersByUserEmail(String email) {
        List<Order> orders = orderRepository.findByUserEmail(email);

        return orders.stream().map(order -> {
            OrderDto dto = new OrderDto();

            dto.setId(order.getId());
            dto.setOrderStatus(order.getStatus()); // ✅ use 'status' field from entity

            // Handle total price safely
            dto.setTotalPrice(order.getTotalPrice() != null ? order.getTotalPrice() : 0.0);

            if (order.getProduct() != null) {
                dto.setProductId(order.getProduct().getId());
                dto.setProductName(order.getProduct().getName());

                // Convert BigDecimal -> Double safely
                dto.setProductPrice(order.getProduct().getPrice() != null
                        ? order.getProduct().getPrice().doubleValue()
                        : 0.0);

                dto.setProductImageUrl(order.getProduct().getImageUrl());
            }

            return dto;
        }).collect(Collectors.toList());
    }



}
