package com.example.application.security;

import com.example.application.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component("orderSecurity") // ✅ this name matches @orderSecurity in @PreAuthorize
public class OrderSecurity {

    @Autowired
    private OrderService orderService;

    public boolean isOrderOwner(Long orderId) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return orderService.isOrderOwnedByUser(orderId, username);
    }
}
