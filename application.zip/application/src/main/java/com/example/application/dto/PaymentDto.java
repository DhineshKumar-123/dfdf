package com.example.application.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class PaymentDto {

    private Long id;

    // ✅ Link to Order after successful payment
    private Long orderId;

    // ✅ Useful when creating order after payment
    private Long userId;
    private Long productId;
    private Integer quantity;

    // ✅ Razorpay fields
    private String razorpayOrderId;
    private String razorpayPaymentId;
    private String razorpaySignature;

    private String paymentMethod;  // e.g., UPI, Card, NetBanking
    private String paymentStatus;  // SUCCESS / FAILED / PENDING
    private BigDecimal amount;

    private LocalDateTime paymentDate;
}
