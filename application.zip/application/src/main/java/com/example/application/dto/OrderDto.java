    package com.example.application.dto;

    import lombok.Data;

    import java.math.BigDecimal;
    import java.time.LocalDateTime;
    import java.util.List;

    @Data
    public class OrderDto {

    //    private Long id;
    //    private Long userId;
    //    private String userName;
    //    private Long productId;
    //    private String shippingAddress;
    //    private Double total;
    //    private String status;
    //    private LocalDateTime date;
    //    private String razorpayOrderId;
    //    private List<OrderItemDto> orderItems;
    //    private LocalDateTime createdAt;

        private Long id;
        private Long productId;
        private String userName;
        private String userEmail;
        private String shippingAddress;
        private String productName;
        private Double totalPrice;
        private String orderStatus;
        private LocalDateTime createdAt;
        private ProductDto product; // ✅ add this field

        private int quantity;


        private String productImageUrl;
        private Double productPrice;

    }
