package com.example.application.config;

import com.example.application.security.CustomSuccessHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    private final CustomSuccessHandler customSuccessHandler;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    	http.csrf(csrf -> csrf.ignoringRequestMatchers("/payments/**"));
http
                .authorizeHttpRequests(auth -> auth
                        // Public pages
                        .requestMatchers("/", "/home", "/login", "/register",
                                "/css/**", "/js/**", "/images/**", "/uploads/**").permitAll()

                        // User module
                        .requestMatchers("/user/profile/**").hasAnyRole("USER", "ADMIN")
                        .requestMatchers("/user/list", "/user/delete/**", "/user/update/**").hasRole("ADMIN")

                        // Product module
                        .requestMatchers("/admin/products/**").hasRole("ADMIN")   // ✅ all admin product actions
                        .requestMatchers("/products/**").hasAnyRole("USER", "ADMIN") // ✅ visible to users & admins

                        // Cart module
                        .requestMatchers("/cartitem/**").hasRole("USER")

                        // Orders
                        .requestMatchers("/orders/create", "/orders/edit/**", "/orders/update/**", "/orders/delete/**").hasAnyRole("USER", "ADMIN")
                        .requestMatchers("/orders", "/orders/**").hasAnyRole("USER", "ADMIN")

                        // Payments
                        .requestMatchers("/payment/create", "/payment/view/**").hasRole("USER")
                        .requestMatchers("/payment/list", "/payment/edit/**", "/payment/delete/**").hasRole("ADMIN")

                        // Admin dashboard
                        .requestMatchers("/admin/**").hasRole("ADMIN")

                        
                        // Everything else must be authenticated
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/login")
                        .successHandler(customSuccessHandler)
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                )
                .exceptionHandling(ex -> ex.accessDeniedHandler(accessDeniedHandler()));

        return http.build();
    }

    @Bean
    public AccessDeniedHandler accessDeniedHandler() {
        return (request, response, accessDeniedException) -> response.sendRedirect("/access-denied");
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}



































//package com.example.application.config;
//
//import com.example.application.security.CustomSuccessHandler;
//import lombok.RequiredArgsConstructor;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.access.AccessDeniedHandler;
//
//@Configuration
//@RequiredArgsConstructor
//public class SecurityConfig {
//
//    private final CustomSuccessHandler customSuccessHandler;
//
//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//                .authorizeHttpRequests(auth -> auth
//                        // Public URLs
//                        .requestMatchers("/", "/home", "/login", "/register", "/css/**", "/js/**", "/images/**").permitAll()
//
//                        // User Module
//                        .requestMatchers("/user/profile/**").hasAnyRole("USER", "ADMIN")
//                        .requestMatchers("/user/list", "/user/delete/**", "/user/update/**").hasRole("ADMIN")
//
//                        // Product Module
//                        .requestMatchers("/products/create", "/products/edit/**", "/products/delete/**", "/products/update/**").hasRole("ADMIN")
//                        .requestMatchers("/products", "/products/**").hasAnyRole("USER", "ADMIN")
//
//                        // Cart Module
//                        .requestMatchers("/cartitem/**").hasRole("USER")
//
//                        // Order Module
//                        .requestMatchers("/orders/create", "/orders/edit/**", "/orders/update/**", "/orders/delete/**").hasAnyRole("USER", "ADMIN")
//                        .requestMatchers("/orders", "/orders/**").hasAnyRole("USER", "ADMIN")
//
//                        // Payment Module
//                        .requestMatchers("/payment/create", "/payment/view/**").hasRole("USER")
//                        .requestMatchers("/payment/list", "/payment/edit/**", "/payment/delete/**").hasRole("ADMIN")
//
//                        // Admin Dashboard
//                        .requestMatchers("/admin/**").hasRole("ADMIN")
//
//                        // Any other request
//                        .anyRequest().authenticated()
//                )
//                .formLogin(form -> form
//                        .loginPage("/login")
//                        .loginProcessingUrl("/login")
//                        .successHandler(customSuccessHandler)
//                        .permitAll()
//                )
//                .logout(logout -> logout
//                        .logoutUrl("/logout")
//                        .logoutSuccessUrl("/login?logout")
//                        .permitAll()
//                )
//                .exceptionHandling(ex -> ex.accessDeniedHandler(accessDeniedHandler()));
//
//        // ✅ CSRF enabled by default (do not disable)
//        return http.build();
//    }
//
//    @Bean
//    public AccessDeniedHandler accessDeniedHandler() {
//        return (request, response, accessDeniedException) -> {
//            response.sendRedirect("/access-denied");
//        };
//    }
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//}





