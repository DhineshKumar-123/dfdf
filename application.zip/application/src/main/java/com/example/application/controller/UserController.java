package com.example.application.controller;


import com.example.application.dto.UserDto;
import com.example.application.entity.User;
import com.example.application.service.UserService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
@RequestMapping("/users")
public class UserController {


    private final UserService userService ;

    // ✅ View user profile
    @GetMapping("/profile/{id}")
    public String viewProfile(@PathVariable Long id, Model model) {
        UserDto user = userService.getUserById(id);
        model.addAttribute("user", user);
        return "user/profile"; // templates/user/profile.html
    }

    // ✅ Edit profile page
    @GetMapping("/profile/edit/{id}")
    public String editProfile(@PathVariable Long id, Model model) {
        UserDto user = userService.getUserById(id);
        model.addAttribute("user", user);
        return "user/edit-profile"; // templates/user/edit-profile.html
    }

    // ✅ Handle profile update
    @PostMapping("/profile/update/{id}")
    public String updateProfile(@PathVariable Long id, @ModelAttribute UserDto userDto) {
        userService.updateUser(id, userDto);
        return "redirect:/user/profile/" + id;
    }
}
