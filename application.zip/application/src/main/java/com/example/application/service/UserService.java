package com.example.application.service;

import com.example.application.dto.UserDto;
import com.example.application.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

    UserDto createUser(UserDto userDtO);
    UserDto getUserById(Long id);

//    UserDto findByEmail(String email);

    List<UserDto> getAllUsers();
    UserDto updateUser(Long id, UserDto userDto);
    void deleteUser(Long id);

    Optional<User> findByEmail(String email);
    void saveUser(UserDto userDto);
    List<UserDto> findAll();

    UserDto findById(Long id);
}
