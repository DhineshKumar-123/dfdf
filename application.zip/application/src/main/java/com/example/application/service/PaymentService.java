package com.example.application.service;

import com.example.application.dto.CartItemDto;
import com.example.application.dto.PaymentDto;
import java.util.List;

public interface PaymentService {

    PaymentDto createPayment(PaymentDto paymentDto);
    PaymentDto getPaymentById(Long id);
    List<PaymentDto> getAllPayments();
    PaymentDto updatePayment(Long id, PaymentDto paymentDto);
    void deletePayment(Long id);
    CartItemDto getCartItemById(Long id);

    // ✅ ADD THIS METHOD (used in controller)
    List<PaymentDto> getPaymentsByUser(String username);
	PaymentDto savePayment(PaymentDto payment);
}
