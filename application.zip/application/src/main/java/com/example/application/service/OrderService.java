package com.example.application.service;

import com.example.application.dto.OrderDto;
import java.util.List;

public interface OrderService {

    OrderDto createOrder(OrderDto orderDto);  // existing

    // ✅ ADD THIS OVERLOADED METHOD (used in controller)
    void createOrder(String username, Long productId, int quantity);

    OrderDto getOrderById(Long id);
    List<OrderDto> getAllOrders();
    OrderDto updateOrder(Long id, OrderDto orderDto);
    void deleteOrder(Long id);
    List<OrderDto> getOrdersByProductId(Long productId);

    boolean isOrderOwnedByUser(Long orderId, String username);
    void updateOrderStatus(Long orderId, String status);

    // ✅ ADD THIS METHOD (used in controller)
    List<OrderDto> getOrdersByUser(String username);

    List<OrderDto> getOrdersByUserEmail(String email);
}
