package com.example.application.service.impl;

import com.example.application.dto.CartItemDto;
import com.example.application.dto.PaymentDto;
import com.example.application.entity.CartItem;
import com.example.application.entity.Payment;
import com.example.application.repository.CartItemRepository;
import com.example.application.repository.PaymentRepository;
import com.example.application.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final CartItemRepository cartItemRepository;
    private final PaymentRepository paymentRepository;
    private final ModelMapper modelMapper;

    @Override
    public PaymentDto createPayment(PaymentDto paymentDto) {
        Payment payment = modelMapper.map(paymentDto, Payment.class);
        return modelMapper.map(paymentRepository.save(payment), PaymentDto.class);
    }

    @Override
    public PaymentDto getPaymentById(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with ID: " + id));
        return modelMapper.map(payment, PaymentDto.class);
    }

    @Override
    public List<PaymentDto> getAllPayments() {
        return paymentRepository.findAll()
                .stream()
                .map(payment -> modelMapper.map(payment, PaymentDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public PaymentDto updatePayment(Long id, PaymentDto paymentDto) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payment not found with ID: " + id));
        modelMapper.map(paymentDto, payment);
        return modelMapper.map(paymentRepository.save(payment), PaymentDto.class);
    }

    @Override
    public void deletePayment(Long id) {
        paymentRepository.deleteById(id);
    }

    @Override
    public CartItemDto getCartItemById(Long id) {
        Optional<CartItem> cartItemOpt = cartItemRepository.findById(id);
        return cartItemOpt.map(cartItem -> modelMapper.map(cartItem, CartItemDto.class)).orElse(null);
    }

    @Override
    public List<PaymentDto> getPaymentsByUser(String email) {
        return paymentRepository.findByUserEmail(email)
                .stream()
                .map(payment -> modelMapper.map(payment, PaymentDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public PaymentDto savePayment(PaymentDto paymentDto) {
        Payment paymentEntity = modelMapper.map(paymentDto, Payment.class);
        Payment saved = paymentRepository.save(paymentEntity);
        return modelMapper.map(saved, PaymentDto.class);
    }

}
