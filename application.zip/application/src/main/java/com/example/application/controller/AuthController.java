package com.example.application.controller;

import com.example.application.dto.UserDto;
import com.example.application.entity.User;
import com.example.application.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UserService userService;
    private final ModelMapper modelMapper;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public AuthController(UserService userService, ModelMapper modelMapper, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.modelMapper = modelMapper;
        this.passwordEncoder = passwordEncoder;
    }

    // ✅ Show login form
    @GetMapping("/login")
    public String showLoginPage() {
        return "auth/login";
    }

    // ✅ Show registration form
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new UserDto());
        return "auth/register";
    }

    // ✅ Handle form submission
    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") UserDto userDto, Model model) {
        try {
            // 🔹 Validate email
            if (userService.findByEmail(userDto.getEmail()).isPresent()) {
                model.addAttribute("error", "Email already registered!");
                return "auth/register";
            }

            // 🔹 Encrypt password in DTO before sending to service
            userDto.setPassword(passwordEncoder.encode(userDto.getPassword()));

            // 🔹 Assign default role if none provided
            if (userDto.getRole() == null || userDto.getRole().isEmpty()) {
                userDto.setRole("USER");
            }

            // 🔹 Save the user DTO
            userService.saveUser(userDto);

            // ✅ Redirect to login with success flag
            return "redirect:/login?registered=true";

        } catch (Exception e) {
            model.addAttribute("error", "Registration failed: " + e.getMessage());
            return "auth/register";
        }
    }

}
