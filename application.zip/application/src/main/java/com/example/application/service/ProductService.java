package com.example.application.service;

import com.example.application.dto.ProductDto;
import com.example.application.entity.Product;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface ProductService {

    ProductDto createProduct(ProductDto productDto, MultipartFile imageFile);
    ProductDto getProductById(Long id);
    List<ProductDto> getAllProducts();
    ProductDto updateProduct(Long id, ProductDto productDto);
    void deleteProduct(Long id);
    List<ProductDto> searchProducts(String keyword);

    ProductDto updateProductWithImage(Long id, ProductDto productDto, MultipartFile imageFile);
    void saveProduct(ProductDto product);
    void saveProductImage(MultipartFile file, Product product);
}
