package com.example.application.controller;

import com.example.application.dto.CartItemDto;
import com.example.application.entity.User;
import com.example.application.service.CartItemService;
import com.example.application.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@Controller
@RequestMapping("/cartitems")
public class CartItemController {

    @Autowired
    private CartItemService cartItemService;

    @Autowired
    private UserService userService;

    /**
     * ✅ View all cart items for the logged-in user
     */
    @GetMapping
    public String viewCartItems(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<CartItemDto> cartItems = cartItemService.getCartItemsByUser(user.getId());
        double total = cartItemService.getTotalAmount(user.getId());

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalAmount", total);
        return "cartitem/list";  // ✅ points to templates/cartitem/list.html
    }

    /**
     * ✅ Add product to cart
     */
    @GetMapping("/add/{productId}")
    public String addToCart(@PathVariable Long productId, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        cartItemService.addToCart(user.getId(), productId, 1);
        return "redirect:/cartitems";
    }

    /**
     * ✅ Update quantity of an item
     */
    @PostMapping("/update/{id}")
    public String updateQuantity(@PathVariable Long id, @RequestParam int quantity) {
        cartItemService.updateQuantity(id, quantity);
        return "redirect:/cartitems";
    }

    /**
     * ✅ Remove item from cart
     */
    @GetMapping("/delete/{id}")
    public String deleteCartItem(@PathVariable Long id) {
        cartItemService.removeFromCart(id);
        return "redirect:/cartitems";
    }

    /**
     * ✅ Checkout page
     */
    @GetMapping("/checkout")
    public String checkout(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        User user = userService.findByEmail(principal.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        double total = cartItemService.getTotalAmount(user.getId());
        model.addAttribute("totalAmount", total);
        return "cartitem/checkout";  // ✅ points to templates/cartitem/checkout.html
    }


    @GetMapping("/increase/{id}")
    public String increaseQuantity(@PathVariable Long id) {
        cartItemService.increaseQuantity(id);
        return "redirect:/cartitems";
    }

    @GetMapping("/decrease/{id}")
    public String decreaseQuantity(@PathVariable Long id) {
        cartItemService.decreaseQuantity(id);
        return "redirect:/cartitems";
    }
}







//package com.example.application.controller;
//
//import com.example.application.dto.CartItemDto;
//import com.example.application.entity.User;
//import com.example.application.service.CartItemService;
//import com.example.application.service.UserService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import java.security.Principal;
//import java.util.List;
//import java.util.Optional;
//
//@Controller
//@RequestMapping("/cartitems")
//public class CartItemController {
//
//    @Autowired
//    private CartItemService cartItemService;
//
//    @Autowired
//    private UserService userService;
//
//    @GetMapping("/cart")
//    public String viewCartItems(Model model, Principal principal) {
//        if (principal == null) {
//            return "redirect:/login";
//        }
//
//        Optional<User> userOpt = userService.findByEmail(principal.getName());
//        if (userOpt.isEmpty()) {
//            return "redirect:/login?error=User+not+found";
//        }
//
//        User user = userOpt.get(); // ✅ unwrap Optional
//
//        List<CartItemDto> cartItems = cartItemService.getCartItemsByUser(user.getId());
//        double total = cartItemService.getTotalAmount(user.getId());
//
//        model.addAttribute("cartItems", cartItems);
//        model.addAttribute("totalAmount", total);
//        return "cartitem/list";
//    }
//
//
//    @GetMapping("/add/{productId}")
//    public String addToCart(@PathVariable Long productId, Principal principal) {
//        // findByEmail returns Optional<User>, so unwrap it properly
//        User user = userService.findByEmail(principal.getName())
//                .orElseThrow(() -> new RuntimeException("User not found"));
//
//        cartItemService.addToCart(user.getId(), productId, 1);
//        return "redirect:/cartitems";
//    }
//
//    @PostMapping("/update/{id}")
//    public String updateQuantity(@PathVariable Long id, @RequestParam int quantity) {
//        cartItemService.updateQuantity(id, quantity);
//        return "redirect:/cartitems";
//    }
//
//    @GetMapping("/delete/{id}")
//    public String deleteCartItem(@PathVariable Long id) {
//        cartItemService.removeFromCart(id);
//        return "redirect:/cartitems";
//    }
//
//    @GetMapping("/checkout")
//    public String checkout(Model model, Principal principal) {
//        // Get user wrapped in Optional
//        Optional<User> optionalUser = userService.findByEmail(principal.getName());
//
//        // Handle case where user is not found
//        if (optionalUser.isEmpty()) {
//            return "redirect:/login?error=User+not+found";
//        }
//
//        // Extract the actual User object
//        User user = optionalUser.get();
//
//        double total = cartItemService.getTotalAmount(user.getId());
//        model.addAttribute("totalAmount", total);
//        return "cartitem/checkout";
//    }
//
//}




























































//package com.example.application.controller;
//
//import com.example.application.dto.CartItemDto;
//import com.example.application.entity.CartItem;
//import com.example.application.service.CartItemService;
//import org.modelmapper.ModelMapper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//
//@Controller
//@RequestMapping("/cartitems")
//public class CartItemController {
//
//    @Autowired
//    private CartItemService cartItemService;
//
//    @Autowired
//    private ModelMapper modelMapper;
//
//    @GetMapping
//    public String listCartItems(Model model) {
//        List<CartItemDto> items = cartItemService.getAllCartItems();
//        model.addAttribute("cartItems", items);
//        return "cartitem/list";
//    }
//
//    @GetMapping("/create")
//    public String createCartItemForm(Model model) {
//        model.addAttribute("cartItem", new CartItemDto());
//        return "cartitem/create";
//    }
//
//    @PostMapping
//    public String createCartItem(@ModelAttribute("cartItem") CartItemDto cartItemDTO) {
//        cartItemService.createCartItem(cartItemDTO);
//        return "redirect:/cartitems";
//    }
//
//    @GetMapping("/{id}")
//    public String viewCartItem(@PathVariable Long id, Model model) {
//        model.addAttribute("cartItem", cartItemService.getCartItemById(id));
//        return "cartitem/view";
//    }
//
//    @GetMapping("/edit/{id}")
//    public String editCartItemForm(@PathVariable Long id, Model model) {
//        model.addAttribute("cartItem", cartItemService.getCartItemById(id));
//        return "cartitem/edit";
//    }
//
//    @PostMapping("/update/{id}")
//    public String updateCartItem(@PathVariable Long id, @ModelAttribute CartItemDto cartItemDTO) {
//        cartItemService.updateCartItem(id, cartItemDTO);
//        return "redirect:/cartitem";
//    }
//
//    @GetMapping("/delete/{id}")
//    public String deleteCartItem(@PathVariable Long id) {
//        cartItemService.deleteCartItem(id);
//        return "redirect:/cartitem";
//    }
//}
